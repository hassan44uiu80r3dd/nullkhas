# nullHas — Student Study Tracker v3.0

## 🚀 Quick Start

```bash
npm install
npm run dev       # start dev server at http://localhost:3000
npm run build     # production build → /dist
npm run preview   # preview build
```

## 📁 Project Structure

```
nullhas/
├── index.html              # App shell
├── package.json
├── vite.config.js
└── src/
    ├── main.js             # Entry point — boot sequence
    ├── data/
    │   ├── store.js        # Central state (D object, all app state)
    │   └── defaults.js     # Default subjects, emoji/color palettes
    ├── storage/
    │   ├── StorageEngine.js # localStorage / IDB / OPFS / memory
    │   ├── idb.js          # IndexedDB for file attachments
    │   └── persist.js      # load() / persist() with debounce
    ├── utils/
    │   ├── helpers.js      # uid, esc, fmtDate, daysUntil, debounce...
    │   └── phase.js        # Semester phase detection engine
    ├── modules/
    │   ├── subjects.js     # Subject CRUD, dashboard
    │   ├── notes.js        # Notes with tags, priority, autosave
    │   ├── assignments.js  # Assignments with subtasks, file attachments
    │   ├── quiz.js         # Quiz records + trend chart
    │   ├── syllabus.js     # Topic tracking + coverage arc
    │   ├── analytics.js    # Home dashboard, KPIs, rings, streak
    │   ├── calendar.js     # Calendar + reminders
    │   ├── timer.js        # Study timer + Pomodoro + weekly chart
    │   ├── notifications.js # Notification center
    │   ├── search.js       # Global search
    │   ├── fab.js          # Floating action button
    │   ├── fileViewer.js   # PDF/DOCX viewer
    │   └── onboarding.js   # First-run profile setup
    ├── ui/
    │   ├── views.js        # Navigation / showView()
    │   ├── modals.js       # Modal open/close, undo bar, confirm dialog
    │   ├── toast.js        # Toast notifications
    │   ├── icons.js        # SVG icon library
    │   ├── theme.js        # Dark/light + accent themes
    │   └── settings.js     # Settings page, PIN lock, export/import
    └── styles/
        ├── base.css        # Design system + all component styles
        └── light-mode.css  # Light mode overrides
```

## 🐛 Bugs Fixed in this Refactor

1. **Double persist on subject delete** — only persists once now
2. **Greeting subtitle** — shows BOTH overdue AND today counts correctly
3. **Quiz count mismatch** — badge shows all quizzes, cards only show valid ones
4. **Storage migration rollback** — uses saved `oldBackend`, not re-read key
5. **Race condition onboarding** — `OnboardingSystem.init()` runs AFTER `await load()`
6. **Reminder scheduler** — single `new Date()` call, no millisecond boundary bug
7. **Navigation state** — detail view still handled; back button works correctly
8. **File attachment validation** — type checked before IDB store
9. **Streak timezone bug** — uses local date components, not `.toDateString()` mix
10. **Duplicate CSS** — removed, single source of truth per selector

## ⚙️ Tech Stack

- **Vite** — build tool, HMR dev server
- **Vanilla JS (ES Modules)** — no framework overhead
- **IndexedDB** — file attachment storage
- **OPFS / IDB / localStorage** — switchable data backends
- **PDF.js + Mammoth.js** — document viewer (CDN)
