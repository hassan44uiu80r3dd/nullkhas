// ── TIMER MODULE ──────────────────────────────────────────────────────────────
import { D, timerRunning, timerElapsed, timerStart_, timerInterval, timerSubjectId, pomoDone,
  setTimerRunning, setTimerElapsed, setTimerStart, setTimerInterval, setTimerSubjectId, setPomoDone } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { toast } from '../ui/toast.js';
import { fmtDur, safeIcon, DAYS } from '../utils/helpers.js';
import { updateStreak } from './analytics.js';

const TIMER_KEY = 'sv4_timer';

export function populateTimerSelect() {
  const sel = document.getElementById('timer-subject-select');
  const cur = sel.value;
  sel.innerHTML = '<option value="">— Choose Subject —</option>';
  D.subjects.forEach(s => {
    const o = document.createElement('option');
    o.value = s.id;
    o.textContent = safeIcon(s.icon) + ' ' + s.name;
    sel.appendChild(o);
  });
  if (cur && D.subjects.find(x => x.id === cur)) sel.value = cur;
  else if (D.subjects.length) sel.value = D.subjects[0].id;
  setTimerSubject();
}

export function setTimerSubject() {
  const val = document.getElementById('timer-subject-select').value;
  setTimerSubjectId(val || null);
  const s   = timerSubjectId ? D.subjects.find(x => x.id === timerSubjectId) : null;
  const lbl = document.getElementById('timer-subject-lbl');
  if (lbl) lbl.textContent = s ? (safeIcon(s.icon) + ' ' + s.name.toUpperCase()) : 'SELECT A SUBJECT';
}

export function timerStart() {
  if (!timerSubjectId) { toast('Please select a subject first!'); return; }
  setTimerRunning(true);
  setTimerStart(Date.now() - (timerElapsed * 1000));
  clearInterval(timerInterval);
  setTimerInterval(setInterval(timerTick, 1000));
  document.getElementById('timer-start-btn').style.display  = 'none';
  document.getElementById('timer-pause-btn').style.display  = '';
  document.getElementById('timer-stop-btn').style.display   = '';
  document.getElementById('timer-card').classList.remove('paused');
  document.getElementById('timer-session-lbl').textContent  = 'Session in progress...';
}

export function timerPause() {
  setTimerRunning(false);
  clearInterval(timerInterval);
  document.getElementById('timer-pause-btn').style.display = 'none';
  document.getElementById('timer-start-btn').style.display = '';
  document.getElementById('timer-start-btn').textContent   = 'Resume';
  document.getElementById('timer-card').classList.add('paused');
  document.getElementById('timer-session-lbl').textContent = 'Paused';
}

export function timerStop() {
  clearInterval(timerInterval);
  try { localStorage.removeItem(TIMER_KEY); } catch (e) {}

  if (timerElapsed >= 60) {
    const s = D.subjects.find(x => x.id === timerSubjectId);
    if (s) {
      if (!D.studyLog) D.studyLog = [];
      D.studyLog.push({
        subjectId:   timerSubjectId,
        subjectName: s.name,
        subjectIcon: s.icon,
        duration:    timerElapsed,
        date:        Date.now()
      });
      persist();
      updateStreak();
      toast('Session saved: ' + fmtDur(timerElapsed));
    }
  } else if (timerElapsed > 0) {
    toast('Session too short — minimum 1 min required');
  }

  setTimerElapsed(0);
  setTimerRunning(false);
  document.getElementById('timer-display').textContent       = '00:00:00';
  document.getElementById('timer-start-btn').style.display   = '';
  document.getElementById('timer-start-btn').textContent     = 'Start';
  document.getElementById('timer-pause-btn').style.display   = 'none';
  document.getElementById('timer-stop-btn').style.display    = 'none';
  document.getElementById('timer-card').classList.remove('paused');
  document.getElementById('timer-session-lbl').textContent   = 'Ready to study';
  setPomoDone(0);
  renderPomoDots();
  renderTimer();
}

export function timerTick() {
  const elapsed = Math.floor((Date.now() - timerStart_) / 1000);
  setTimerElapsed(elapsed);
  const h = Math.floor(elapsed / 3600), m = Math.floor((elapsed % 3600) / 60), s = elapsed % 60;
  document.getElementById('timer-display').textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;

  const completedPomos = Math.floor(elapsed / 1500);
  if (completedPomos > pomoDone) { setPomoDone(completedPomos); renderPomoDots(); toast('🍅 Pomodoro complete! 5 min break lo'); }
  if (elapsed % 10 === 0) saveTimerState();
}

function saveTimerState() {
  if (timerRunning && timerSubjectId) {
    try { localStorage.setItem(TIMER_KEY, JSON.stringify({ subjectId: timerSubjectId, startTime: timerStart_, elapsed: timerElapsed })); } catch (e) {}
  } else {
    try { localStorage.removeItem(TIMER_KEY); } catch (e) {}
  }
}

export function restoreTimerState() {
  try {
    const raw = localStorage.getItem(TIMER_KEY); if (!raw) return;
    const saved = JSON.parse(raw);
    if (!saved.subjectId || !saved.startTime) return;
    if (Date.now() - saved.startTime > 4 * 3600 * 1000) { localStorage.removeItem(TIMER_KEY); return; }
    setTimerSubjectId(saved.subjectId);
    setTimerStart(saved.startTime);
    setTimerElapsed(Math.floor((Date.now() - saved.startTime) / 1000));
    setTimerRunning(true);
    clearInterval(timerInterval);
    setTimerInterval(setInterval(timerTick, 1000));
    document.getElementById('timer-start-btn').style.display = 'none';
    document.getElementById('timer-pause-btn').style.display = '';
    document.getElementById('timer-stop-btn').style.display  = '';
    document.getElementById('timer-card').classList.remove('paused');
    document.getElementById('timer-session-lbl').textContent = 'Session restored';
    toast('⏱️ Timer session restored!');
  } catch (e) {}
}

export function renderPomoDots() {
  const wrap = document.getElementById('pomo-dots'); if (!wrap) return;
  wrap.innerHTML = '';
  for (let i = 0; i < 4; i++) {
    const d = document.createElement('div');
    d.className = 'pomo-dot' + (i < pomoDone ? ' done' : '');
    wrap.appendChild(d);
  }
}

export function renderTimer() {
  renderPomoDots();
  const log   = (D.studyLog || []).slice().reverse().slice(0, 10);
  const logEl = document.getElementById('study-log');
  if (!logEl) return;
  logEl.innerHTML = '';

  if (!log.length) {
    logEl.innerHTML = `<div class="empty-state"><div class="empty-emoji">⏱️</div><div class="empty-msg">No study sessions yet</div><div class="empty-hint">Use the timer to study and track your progress</div></div>`;
  } else {
    log.forEach(l => {
      const d    = document.createElement('div');
      d.className = 'study-log-item';
      const dt   = new Date(l.date);
      const dtStr = dt.toLocaleDateString('en-PK',{ day:'2-digit', month:'short' }) + ' ' + dt.toLocaleTimeString('en-PK',{ hour:'2-digit', minute:'2-digit' });
      const icon = safeIcon(l.subjectIcon);
      d.innerHTML = `<div><div class="study-log-sub">${icon} ${l.subjectName || ''}</div><div class="study-log-date">${dtStr}</div></div><div class="study-log-dur">${fmtDur(l.duration)}</div>`;
      logEl.appendChild(d);
    });
  }

  // Weekly bar chart
  const whEl = document.getElementById('weekly-hours'); if (!whEl) return;
  whEl.innerHTML = '';
  const now = new Date(), dayHours = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now); d.setDate(now.getDate() - i);
    dayHours[d.toDateString()] = 0;
  }
  (D.studyLog || []).forEach(l => {
    const key = new Date(l.date).toDateString();
    if (Object.hasOwn(dayHours, key)) dayHours[key] += l.duration;
  });
  const maxH = Math.max(...Object.values(dayHours), 1);
  Object.entries(dayHours).forEach(([ds, sec]) => {
    const d   = new Date(ds);
    const pct = (sec / maxH) * 100;
    const hrs = (sec / 3600).toFixed(1);
    const div = document.createElement('div');
    div.className = 'day-bar-wrap';
    div.innerHTML = `<div class="day-bar-track"><div class="day-bar-fill" style="height:${pct}%"></div></div><div class="day-bar-lbl">${DAYS[d.getDay()]}</div><div class="day-bar-val">${sec > 0 ? hrs + 'h' : ''}</div>`;
    whEl.appendChild(div);
  });
}

export function clearStudyLog() {
  import('../ui/modals.js').then(m => m.confirmDelete(
    'Clear study log?', 'All sessions will be deleted.',
    () => { D.studyLog = []; persist(); renderTimer(); updateStreak(); }
  ));
}

// Save timer on page close
window.addEventListener('beforeunload', () => { if (timerRunning) saveTimerState(); });
