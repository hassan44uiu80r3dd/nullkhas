// ── ONBOARDING SYSTEM ─────────────────────────────────────────────────────────
import { D } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { toast } from '../ui/toast.js';

const PROFILE_KEY = 'sv_user_profile';

export const OnboardingSystem = {
  init() {
    const saved = localStorage.getItem(PROFILE_KEY);
    if (!saved) { this.show(); }
    else { this.applyProfile(JSON.parse(saved)); }
  },

  show() {
    const tpl = document.createElement('div');
    tpl.id = 'ob-overlay';
    tpl.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(4,4,8,0.85);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:center;animation:fadeUp 0.4s ease;';
    tpl.innerHTML = `
      <div class="modal" style="max-width:400px;border:1px solid rgba(165,175,210,0.2);background:rgba(10,10,20,0.95);">
        <div class="modal-hd" style="border-bottom:1px solid rgba(255,255,255,0.07);padding:20px;">
          <span style="font-family:var(--font-display);font-size:18px;font-weight:800;">Welcome to nullHas</span>
        </div>
        <div style="padding:24px;">
          <p style="font-size:13px;color:rgba(255,255,255,0.4);margin-bottom:20px;">Set up your profile to personalize your experience.</p>
          <div class="fg" style="margin-bottom:16px;">
            <label class="fg-label" style="display:block;margin-bottom:8px;">Full Name</label>
            <input type="text" id="user-name-input" class="fi" placeholder="e.g. Ali Khan" style="width:100%;">
          </div>
          <div class="fg" style="margin-bottom:16px;">
            <label class="fg-label" style="display:block;margin-bottom:8px;">Major / Course</label>
            <input type="text" id="user-major-input" class="fi" placeholder="e.g. Computer Science" style="width:100%;">
          </div>
          <div class="fg" style="margin-bottom:24px;">
            <label class="fg-label" style="display:block;margin-bottom:8px;">Current Semester</label>
            <select id="user-sem-input" class="fi" style="width:100%;">
              ${[1,2,3,4,5,6,7,8].map(i => `<option value="${i}">Semester ${i}</option>`).join('')}
            </select>
          </div>
          <button id="save-profile-btn" class="moda-btn">Start Journey 🚀</button>
        </div>
      </div>`;
    document.body.appendChild(tpl);
    document.getElementById('save-profile-btn').onclick = () => this.handleSave();
    setTimeout(() => document.getElementById('user-name-input')?.focus(), 300);
  },

  handleSave() {
    const name  = document.getElementById('user-name-input').value.trim();
    const major = document.getElementById('user-major-input').value.trim();
    const sem   = document.getElementById('user-sem-input').value;
    if (!name || !major) { toast('Please fill in all fields!'); return; }

    const profile = { name, major, semester: sem };
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));

    if (!D.settings) D.settings = { name:'', pinEnabled:false, pin:'', major:'', semester:'' };
    D.settings.name     = name;
    D.settings.major    = major;
    D.settings.semester = sem;
    persist();

    const ov = document.getElementById('ob-overlay');
    if (ov) {
      ov.style.opacity    = '0';
      ov.style.transition = 'opacity .3s';
      setTimeout(() => { ov.remove(); this.applyProfile(profile); toast('Welcome, ' + name + '! 🎉'); }, 300);
    }
  },

  applyProfile(data) {
    if (!data?.name) return;
    const firstName = (data.name || '').trim().split(' ')[0] || data.name;
    const greeting  = document.querySelector('.greeting-text');
    if (greeting) {
      const h    = new Date().getHours();
      const wish = h < 12 ? 'Morning' : h < 18 ? 'Afternoon' : 'Evening';
      greeting.textContent = 'Good ' + wish + ', ' + firstName + '!';
    }
    const sub = document.querySelector('.greeting-sub');
    if (sub && sub.textContent === 'Loading your study overview...') {
      sub.textContent = (data.major || '') + (data.semester ? ' • Semester ' + data.semester : '');
    }
  }
};
