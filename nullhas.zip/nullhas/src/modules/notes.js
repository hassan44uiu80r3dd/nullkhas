// ── NOTES MODULE ──────────────────────────────────────────────────────────────
import { D, getSub, currentNoteId_read, setCurrentNoteId_read, autoSaveTimer, setAutoSaveTimer } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { dbSet, dbGet } from '../storage/idb.js';
import { openModal, closeModal, confirmDelete, showUndo } from '../ui/modals.js';
import { toast } from '../ui/toast.js';
import { uid, esc, fmtDate } from '../utils/helpers.js';
import { ICONS } from '../ui/icons.js';
import { setTabCnt, updateHeroQS } from './subjects.js';

let noteFilter = 'all';
export function setNoteFilter(f) { noteFilter = f; }
export function getNoteFilter()  { return noteFilter; }

export function renderNotes() {
  const s = getSub(); if (!s) return;
  const g = document.getElementById('notes-grid');
  document.getElementById('notes-cnt').textContent = s.notes.length;
  setTabCnt('notes', s.notes.length);

  const deepQ    = (document.getElementById('note-search-input')?.value || '').toLowerCase().trim();
  const allTags  = [...new Set(s.notes.flatMap(n => n.tags || []))];
  const fb       = document.getElementById('note-filter-bar');
  fb.innerHTML   = '';

  const validFilters = ['all','__starred__','__gap__','__review__','__mastered__', ...allTags];
  if (!validFilters.includes(noteFilter)) noteFilter = 'all';

  const makeBtn = (lbl, val) => {
    const b = document.createElement('div');
    b.className = 'nf-btn' + (noteFilter === val ? ' on' : '');
    b.textContent = lbl;
    b.onclick = () => { noteFilter = val; renderNotes(); };
    fb.appendChild(b);
  };

  makeBtn('All', 'all');
  makeBtn('⭐ Starred', '__starred__');
  if (allTags.length) {
    fb.appendChild(Object.assign(document.createElement('div'), { className: 'nf-sep' }));
    allTags.forEach(tag => makeBtn(tag, tag));
    fb.appendChild(Object.assign(document.createElement('div'), { className: 'nf-sep' }));
  }
  makeBtn('🔴 Gap', '__gap__');
  makeBtn('🟡 Review', '__review__');
  makeBtn('🟢 Mastered', '__mastered__');

  let notes = [...s.notes].reverse();
  if (noteFilter === '__starred__')  notes = notes.filter(n => n.starred);
  else if (noteFilter === '__gap__') notes = notes.filter(n => n.priority === 'gap');
  else if (noteFilter === '__review__')   notes = notes.filter(n => n.priority === 'review');
  else if (noteFilter === '__mastered__') notes = notes.filter(n => n.priority === 'mastered');
  else if (noteFilter !== 'all') notes = notes.filter(n => (n.tags || []).includes(noteFilter));

  if (deepQ) {
    notes = notes.filter(n =>
      n.title.toLowerCase().includes(deepQ) ||
      (n.html || '').replace(/<[^>]+>/g, ' ').toLowerCase().includes(deepQ)
    );
  }

  if (!notes.length) {
    g.innerHTML = `<div class="empty-state"><div class="empty-emoji">📝</div><div class="empty-msg">No notes found</div><div class="empty-hint">Add a note or change the filter</div><button class="empty-cta" onclick="openNoteModal()">New Note</button></div>`;
    return;
  }

  g.innerHTML = '';
  notes.forEach(n => {
    const preview  = (n.html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 90);
    const prioMap  = { gap: '🔴', review: '🟡', mastered: '🟢' };
    const prioBadge = n.priority ? `<span class="note-prio-badge">${prioMap[n.priority] || ''} ${n.priority}</span>` : '';
    const tagHtml  = (n.tags || []).map(t => `<span class="note-tag">${esc(t)}</span>`).join('');

    const card = document.createElement('div');
    card.className = 'note-card' + (n.starred ? ' starred' : '');
    card.innerHTML = `
      <div class="note-card-top">
        <div class="note-card-title">${esc(n.title)}</div>
        ${prioBadge}
        ${n.starred ? `<div class="note-star-badge">${ICONS.starFilled}</div>` : ''}
      </div>
      ${preview ? `<div class="note-card-preview">${esc(preview)}</div>` : ''}
      ${tagHtml ? `<div class="note-tags-row">${tagHtml}</div>` : ''}
      <div class="note-card-footer">
        <div class="note-card-date">${fmtDate(n.date || n.id)}</div>
        <div class="note-card-actions">
          <div class="item-btn edit" onclick="event.stopPropagation();window._openNote('${n.id}')">${ICONS.edit}</div>
          <div class="item-btn del"  onclick="event.stopPropagation();window._delNote('${n.id}')">${ICONS.trash}</div>
        </div>
      </div>`;
    card.onclick = () => openReadNote(n.id);
    g.appendChild(card);
  });
}

// ── OPEN NOTE MODAL ───────────────────────────────────────────────────────────
export function openNoteModal(editId = null) {
  const s = getSub(); if (!s) return;
  const note = editId ? s.notes.find(n => n.id === editId) : null;

  document.getElementById('ni-title').value = note?.title || '';
  document.getElementById('rte-body').innerHTML = note?.html  || '';
  const editIdEl = document.getElementById('note-edit-id');
  if (editIdEl) editIdEl.value = editId || '';
  const prio = note?.priority || '';
  const prioEl = document.getElementById('ni-priority');
  if (prioEl) prioEl.value = prio;
  setNotePriority(prio || '');

  // Tags
  const tagArea = document.getElementById('tag-display-area');
  if (tagArea) tagArea.innerHTML = '';
  (note?.tags || []).forEach(t => _addTagChip(t));
  const tagInp = document.getElementById('tag-input');
  if (tagInp) tagInp.value = '';

  // Clear autosave
  clearTimeout(autoSaveTimer);
  setAutoSaveTimer(null);

  openModal('modal-note');
  setTimeout(() => document.getElementById('ni-title').focus(), 200);
}

export function saveNote() {
  const s     = getSub(); if (!s) return;
  const title = document.getElementById('ni-title').value.trim();
  const html  = document.getElementById('rte-body').innerHTML;
  const editId = document.getElementById('note-edit-id').value;
  const priority = document.getElementById('ni-priority').value || '';
  const tags  = [...document.querySelectorAll('.tag-chip')].map(c => c.dataset.tag);

  if (!title) { toast('Please enter a note title!'); return; }

  if (editId) {
    const n = s.notes.find(x => x.id === editId);
    if (n) { n.title = title; n.html = html; n.priority = priority; n.tags = tags; }
    toast('Note updated! ✏️');
  } else {
    s.notes.push({ id: uid(), title, html, priority, tags, date: new Date().toISOString().slice(0,10), starred: false });
    toast('Note saved! 📝');
  }
  persist(); renderNotes(); updateHeroQS(); closeModal('modal-note');
  clearTimeout(autoSaveTimer); setAutoSaveTimer(null);
}

export function confirmCloseNote() {
  const title = document.getElementById('ni-title').value.trim();
  const html  = document.getElementById('rte-body').innerHTML;
  if (!title && (!html || html === '<br>' || html === '')) { closeModal('modal-note'); return; }
  confirmDelete('Discard changes?', 'Unsaved changes will be lost.', () => closeModal('modal-note'));
}

// ── READ NOTE ────────────────────────────────────────────────────────────────
export function openReadNote(id) {
  const s = getSub(); if (!s) return;
  const n = s.notes.find(x => x.id === id); if (!n) return;
  setCurrentNoteId_read(id);
  document.getElementById('rn-title').textContent = n.title;
  document.getElementById('rn-body').innerHTML = n.html || '<em style="color:rgba(255,255,255,0.2)">Empty note</em>';
  const starBtn = document.getElementById('rn-star-btn');
  const starLbl = document.getElementById('rn-star-lbl');
  if (starBtn) starBtn.classList.toggle('starred', !!n.starred);
  if (starLbl) starLbl.textContent = n.starred ? 'Unfavorite' : 'Favorite';
  openModal('modal-read');
}

export function toggleReadNoteStar() {
  const s = getSub(); if (!s || !currentNoteId_read) return;
  const n = s.notes.find(x => x.id === currentNoteId_read); if (!n) return;
  n.starred = !n.starred;
  persist(); renderNotes();
  const starLbl = document.getElementById('rn-star-lbl');
  if (starLbl) starLbl.textContent = n.starred ? 'Unfavorite' : 'Favorite';
  document.getElementById('rn-star-btn')?.classList.toggle('starred', n.starred);
  toast(n.starred ? '⭐ Added to favorites' : '☆ Removed from favorites');
}

// ── DELETE NOTE ───────────────────────────────────────────────────────────────
export function delNoteWithUndo(id) {
  const s = getSub(); if (!s) return;
  const idx = s.notes.findIndex(n => n.id === id); if (idx < 0) return;
  const backup = JSON.parse(JSON.stringify(s.notes[idx]));
  s.notes.splice(idx, 1);
  persist(); renderNotes(); updateHeroQS();
  showUndo('Note deleted', () => { s.notes.splice(idx, 0, backup); persist(); renderNotes(); updateHeroQS(); });
}

// ── PRIORITY ─────────────────────────────────────────────────────────────────
export function setNotePriority(p) {
  const inp = document.getElementById('ni-priority');
  if (inp) inp.value = p || '';
  document.querySelectorAll('.priority-flags .pf-btn').forEach(b => b.classList.remove('selected'));
  if (p) {
    const btn = document.getElementById('pf-' + p);
    if (btn) btn.classList.add('selected');
  }
}

// ── TAG SYSTEM ────────────────────────────────────────────────────────────────
function _addTagChip(tag) {
  const area = document.getElementById('tag-display-area'); if (!area) return;
  const chip = document.createElement('div');
  chip.className = 'tag-chip';
  chip.dataset.tag = tag;
  chip.innerHTML = `${esc(tag)} <span class="tag-remove" onclick="this.parentElement.remove()">×</span>`;
  area.appendChild(chip);
}

export function handleTagInput(e) {
  if (e.key === 'Enter' || e.key === ',') {
    e.preventDefault();
    const val = e.target.value.trim().replace(/,/g, '');
    if (val) { _addTagChip(val); e.target.value = ''; }
  }
}

// ── AUTOSAVE ─────────────────────────────────────────────────────────────────
export function scheduleAutoSave() {
  clearTimeout(autoSaveTimer);
  setAutoSaveTimer(setTimeout(() => {
    const idEl = document.getElementById('note-edit-id');
    const id = idEl ? idEl.value : '';
    if (id) saveNote();
  }, 8000));
}

// ── EXPORT ───────────────────────────────────────────────────────────────────
export function exportCurrentNotePDF() {
  const title = document.getElementById('rn-title')?.textContent || 'Note';
  const body  = document.getElementById('rn-body')?.innerHTML || '';
  const win   = window.open('', '_blank');
  if (!win) { toast('Popup blocked — allow popups to export PDF'); return; }
  win.document.write(`<!DOCTYPE html><html><head><title>${esc(title)}</title><meta charset="utf-8"><style>body{font-family:Georgia,serif;max-width:800px;margin:40px auto;line-height:1.7;padding:20px;} h1,h2{font-family:inherit;} pre{background:#f4f4f4;padding:12px;overflow-x:auto;}</style></head><body><h1>${esc(title)}</h1>${body}</body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); }, 250);
  toast('Use "Save as PDF" in the print dialog');
}

export function exportCurrentNoteDOCX() {
  toast('📝 DOCX export — use Print or Export PDF for now');
}

export function printNote() {
  const title = document.getElementById('rn-title').textContent;
  const body  = document.getElementById('rn-body').innerHTML;
  const win   = window.open('', '_blank');
  win.document.write(`<!DOCTYPE html><html><head><title>${title}</title><style>body{font-family:Georgia,serif;max-width:800px;margin:40px auto;line-height:1.7;}</style></head><body><h1>${title}</h1>${body}</body></html>`);
  win.document.close();
  win.print();
}

// ── GLOBAL BINDINGS ───────────────────────────────────────────────────────────
window._openNote = (id) => openNoteModal(id);
window._delNote  = (id) => confirmDelete('Delete note?', 'This cannot be undone.', () => delNoteWithUndo(id));
