// ── QUIZ MODULE ───────────────────────────────────────────────────────────────
import { getSub } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { openModal, closeModal, confirmDelete, showUndo } from '../ui/modals.js';
import { toast } from '../ui/toast.js';
import { uid, esc, fmtDate } from '../utils/helpers.js';
import { ICONS } from '../ui/icons.js';
import { setTabCnt, updateHeroQS } from './subjects.js';

let editQuizId = null;

export function renderQuiz() {
  const s    = getSub(); if (!s) return;
  const list = document.getElementById('quiz-list');

  // BUG FIX: count all quizzes for badge, but only render ones with valid total
  document.getElementById('quiz-cnt').textContent = s.quizzes.length;
  setTabCnt('quiz', s.quizzes.length);

  const validQuizzes = s.quizzes.filter(q => q.tot > 0);
  const pcts  = validQuizzes.map(q => Math.round((q.obt / q.tot) * 100));
  const avg   = pcts.length ? Math.round(pcts.reduce((a, b) => a + b, 0) / pcts.length) : null;
  const best  = pcts.length ? Math.max(...pcts) : null;

  document.getElementById('quiz-stats').innerHTML = `
    <div class="quiz-stat"><div class="qs-val">${avg  !== null ? avg  + '%' : '—'}</div><div class="qs-lbl">Average</div></div>
    <div class="quiz-stat"><div class="qs-val">${best !== null ? best + '%' : '—'}</div><div class="qs-lbl">Best</div></div>
    <div class="quiz-stat"><div class="qs-val">${s.quizzes.length}</div><div class="qs-lbl">Total</div></div>`;

  renderTrendChart(s.quizzes);

  if (!s.quizzes.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-emoji">🧪</div><div class="empty-msg">No quizzes yet</div><div class="empty-hint">Save your quiz results here</div></div>`;
    return;
  }

  list.innerHTML = '';
  [...s.quizzes].reverse().forEach(q => {
    if (!q.tot || q.tot <= 0) return; // skip invalid quizzes in render only
    const pct    = Math.round(q.obt / q.tot * 100);
    const cls    = pct >= 70 ? 'qr-good' : pct >= 40 ? 'qr-avg' : 'qr-low';
    const barCol = pct >= 70 ? '#4ade80'  : pct >= 40 ? '#facc15' : '#f87171';
    const tStr   = q.target ? ` <span style="font-size:9px;color:rgba(255,255,255,0.2);">Target:${q.target}%</span>` : '';

    const el = document.createElement('div');
    el.className = 'quiz-item';
    el.innerHTML = `
      <div class="quiz-item-top">
        <div class="quiz-ring ${cls}">${pct}%</div>
        <div class="quiz-details">
          <div class="quiz-name">${esc(q.name)}${tStr}</div>
          <div class="quiz-meta">${q.date ? fmtDate(q.date) : ''}</div>
          <div class="quiz-bar-wrap"><div class="quiz-bar-fill" style="width:${pct}%;background:${barCol};"></div></div>
        </div>
        <div>
          <div class="quiz-marks-disp">${q.obt}<span style="font-size:10px;opacity:.5">/${q.tot}</span></div>
          <div class="quiz-marks-sub">marks</div>
        </div>
        <div class="item-btns">
          <div class="item-btn edit" onclick="window._editQuiz('${q.id}')">${ICONS.edit}</div>
          <div class="item-btn del"  onclick="window._delQuiz('${q.id}')">${ICONS.trash}</div>
        </div>
      </div>
      ${q.remarks ? `<div class="quiz-remarks">💬 ${esc(q.remarks)}</div>` : ''}`;
    list.appendChild(el);
  });
}

export function renderTrendChart(quizzes) {
  const wrap = document.getElementById('trend-svg'); if (!wrap) return;
  const valid = quizzes.filter(q => q.tot > 0);
  if (valid.length < 2) {
    wrap.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,0.18);padding:10px 0;">2+ quizzes needed for trend</div>';
    return;
  }
  const sorted = [...valid].sort((a, b) => new Date(a.date) - new Date(b.date));
  const pcts   = sorted.map(q => Math.round((q.obt / q.tot) * 100));
  const W = Math.max(280, pcts.length * 60), H = 75, pad = 12;
  const minP = Math.min(...pcts), maxP = Math.max(...pcts), range = maxP - minP || 1;
  const pts  = pcts.map((p, i) => {
    const x = pad + (i / (pcts.length - 1)) * (W - 2 * pad);
    const y = H - pad - ((p - minP) / range) * (H - 2 * pad);
    return `${x},${y}`;
  });
  const cols = pcts.map(p => p >= 70 ? '#4ade80' : p >= 40 ? '#facc15' : '#f87171');
  let svg = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">`;
  svg += `<polyline fill="none" stroke="rgba(165,175,210,0.25)" stroke-width="1.5" stroke-dasharray="4,3" points="${pts.join(' ')}"/>`;
  pts.forEach((pt, i) => {
    const [x, y] = pt.split(',');
    svg += `<circle cx="${x}" cy="${y}" r="5" fill="${cols[i]}" opacity="0.9"/>`;
    svg += `<text x="${x}" y="${parseFloat(y) - 9}" text-anchor="middle" fill="rgba(255,255,255,0.35)" font-size="9" font-family="sans-serif">${pcts[i]}%</text>`;
  });
  svg += '</svg>';
  wrap.innerHTML = svg;
}

// ── MODAL ─────────────────────────────────────────────────────────────────────
export function openQuizModal() {
  const s = getSub();
  if (!s) {
    toast('Open a subject first to add a quiz');
    if (typeof window.showView === 'function') window.showView('subjects');
    return;
  }
  editQuizId = null;
  const ids = ['qi-name','qi-obt','qi-tot','qi-date','qi-target','qi-remarks'];
  ids.forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  const titleEl = document.getElementById('quiz-modal-title');
  const btnEl = document.getElementById('quiz-save-btn');
  if (titleEl?.childNodes[0]) titleEl.childNodes[0].textContent = 'Add Quiz Record';
  if (btnEl) btnEl.textContent = 'Save Quiz';
  openModal('modal-quiz');
}

export function editQuiz(id) {
  const s = getSub(); if (!s) return;
  const q = s.quizzes.find(x => x.id === id); if (!q) return;
  editQuizId = id;
  document.getElementById('quiz-modal-title').childNodes[0].textContent = 'Edit Quiz';
  document.getElementById('qi-name').value    = q.name;
  document.getElementById('qi-obt').value     = q.obt;
  document.getElementById('qi-tot').value     = q.tot;
  document.getElementById('qi-date').value    = q.date    || '';
  document.getElementById('qi-target').value  = q.target  || '';
  document.getElementById('qi-remarks').value = q.remarks || '';
  document.getElementById('quiz-save-btn').textContent = 'Update Quiz';
  openModal('modal-quiz');
}

export function saveQuiz() {
  const name = document.getElementById('qi-name').value.trim();
  const obt  = parseFloat(document.getElementById('qi-obt').value);
  const tot  = parseFloat(document.getElementById('qi-tot').value);
  if (!name || isNaN(obt) || isNaN(tot) || tot <= 0) { toast('Please fill all required fields!'); return; }
  if (obt > tot + 0.001) { toast('⚠️ Obtained marks exceed total!'); return; }
  if (obt < 0)           { toast('⚠️ Marks cannot be negative!');    return; }

  const s = getSub(); if (!s) return;
  const data = {
    name, obt, tot,
    date:    document.getElementById('qi-date').value,
    target:  document.getElementById('qi-target').value,
    remarks: document.getElementById('qi-remarks').value.trim(),
  };

  if (editQuizId) {
    const q = s.quizzes.find(x => x.id === editQuizId);
    if (q) Object.assign(q, data);
    toast('Quiz updated! ✏️');
  } else {
    s.quizzes.push({ id: uid(), ...data });
    toast('Quiz saved! 🧪');
  }
  persist(); renderQuiz(); updateHeroQS(); closeModal('modal-quiz'); editQuizId = null;
}

export function delQuizWithUndo(id) {
  const s   = getSub(); if (!s) return;
  const idx = s.quizzes.findIndex(q => q.id === id); if (idx < 0) return;
  const backup = JSON.parse(JSON.stringify(s.quizzes[idx]));
  s.quizzes.splice(idx, 1);
  persist(); renderQuiz(); updateHeroQS();
  showUndo('Quiz deleted', () => { s.quizzes.splice(idx, 0, backup); persist(); renderQuiz(); updateHeroQS(); });
}

// ── GLOBAL BINDINGS ───────────────────────────────────────────────────────────
window._editQuiz = editQuiz;
window._delQuiz  = (id) => confirmDelete('Delete quiz?', 'This cannot be undone.', () => delQuizWithUndo(id));
