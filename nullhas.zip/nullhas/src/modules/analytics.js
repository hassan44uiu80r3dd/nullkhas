// ── ANALYTICS / HOME VIEW ─────────────────────────────────────────────────────
import { D } from '../data/store.js';
import { esc, fmtDate, daysUntil, DAYS } from '../utils/helpers.js';
import { detectPhase, getPhaseLabel, getPhaseNotifications, SD } from '../utils/phase.js';
import { showView } from '../ui/views.js';

// ── GREETING ─────────────────────────────────────────────────────────────────
export function renderGreeting() {
  const h      = new Date().getHours();
  const name   = D.settings?.name;
  const greet  = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const el     = document.getElementById('greeting-text');
  if (el) el.textContent = name ? `${greet}, ${name}` : greet;

  // BUG FIX: show BOTH overdue and today counts
  const overdue = D.subjects.reduce((a, s) => a + s.assignments.filter(x => !x.done && daysUntil(x.due) < 0).length, 0);
  const today   = D.subjects.reduce((a, s) => a + s.assignments.filter(x => !x.done && daysUntil(x.due) === 0).length, 0);

  let sub = 'All caught up';
  if (overdue && today)       sub = `${overdue} overdue · ${today} due today`;
  else if (overdue)           sub = `${overdue} assignment${overdue > 1 ? 's' : ''} overdue`;
  else if (today)             sub = `${today} assignment${today > 1 ? 's' : ''} due today`;

  const subEl = document.getElementById('greeting-sub');
  if (subEl) subEl.textContent = sub;
}

// ── PHASE BANNER ─────────────────────────────────────────────────────────────
export function renderPhaseBanner() {
  const wrap = document.getElementById('phase-banner-wrap'); if (!wrap) return;
  const ph   = detectPhase();
  const info = getPhaseLabel(ph);
  let daysHtml = '';

  if (ph === 'pre-mid' && SD.mid) {
    const d = daysUntil(SD.mid);
    if (d !== null) daysHtml = `<div class="phase-days">${d > 0 ? d + ' days to Mid' : d === 0 ? 'Mid Today!' : 'Mid Passed'}</div>`;
  } else if (ph === 'post-mid' && SD.final) {
    const d = daysUntil(SD.final);
    if (d !== null) daysHtml = `<div class="phase-days">${d > 0 ? d + ' days to Final' : d === 0 ? 'Final Today!' : 'Final Passed'}</div>`;
  } else if (ph === 'final' && SD.final) {
    // BUG FIX: null check on d
    const d = daysUntil(SD.final);
    if (d !== null) daysHtml = `<div class="phase-days">${d < 0 ? 'Semester Ended' : d === 0 ? 'Final Today!' : 'Finals in ' + d + 'd'}</div>`;
  } else if (ph === 'none') {
    daysHtml = `<div class="phase-configure-btn" onclick="window.showView('settings')">Configure Dates →</div>`;
  }

  wrap.innerHTML = `<div class="phase-banner ${info.cls}"><div class="phase-dot"></div><div><div class="phase-label">${info.emoji} ${info.text}</div><div class="phase-sub">${info.sub}</div></div>${daysHtml}</div>`;
}

export function renderPhaseNotifications() {
  const wrap  = document.getElementById('phase-notif-wrap'); if (!wrap) return;
  const items = getPhaseNotifications(D.subjects);
  if (!items.length) { wrap.style.display = 'none'; wrap.innerHTML = ''; return; }
  wrap.style.display = 'flex';
  wrap.innerHTML = items.map(it => `
    <div class="phase-notif-item ${it.urgent ? '' : 'warn'}">
      <div class="phase-notif-icon">${it.icon}</div>
      <div class="phase-notif-info">
        <div class="phase-notif-title">${esc(it.title)}</div>
        <div class="phase-notif-sub">${esc(it.sub)}</div>
      </div>
      <div class="phase-notif-badge ${it.badge}">${it.badge === 'urgent' ? '⚠ Urgent' : 'Soon'}</div>
    </div>`).join('');
}

// ── KPI CARDS ─────────────────────────────────────────────────────────────────
export function renderAnalytics() {
  renderGreeting();
  renderPhaseBanner();
  renderPhaseNotifications();

  const ss   = D.subjects;
  const tN   = ss.reduce((a, s) => a + s.notes.length, 0);
  const tA   = ss.reduce((a, s) => a + s.assignments.length, 0);
  const dA   = ss.reduce((a, s) => a + s.assignments.filter(x => x.done).length, 0);
  const pendingNotes   = ss.reduce((a, s) => a + s.notes.filter(n => !n.html || n.html.trim() === '' || n.html === '<br>').length, 0);
  const pendingAsgn    = ss.reduce((a, s) => a + s.assignments.filter(x => !x.done).length, 0);
  const pendingQuizzes = ss.reduce((a, s) => a + s.quizzes.filter(q => q.tot > 0 && Math.round((q.obt / q.tot) * 100) < 50).length, 0);
  const allP = ss.flatMap(s => s.quizzes.filter(q => q.tot > 0).map(q => Math.round((q.obt / q.tot) * 100)));
  const gAvg = allP.length ? Math.round(allP.reduce((a, b) => a + b, 0) / allP.length) : null;

  const kpis = document.getElementById('an-kpis');
  kpis.innerHTML = '';
  [
    { v: ss.length,       l: 'Subjects',     s: 'total enrolled',    c: '#a5afc8' },
    { v: pendingNotes,    l: 'Pending Notes', s: `${tN} total`,       c: '#c084fc' },
    { v: pendingAsgn,     l: 'Pending Tasks', s: `${dA} completed`,   c: '#facc15' },
    { v: pendingQuizzes,  l: 'Low Quizzes',   s: gAvg !== null ? `avg ${gAvg}%` : 'no data yet', c: '#f87171' },
  ].forEach(k => {
    const d = document.createElement('div');
    d.className = 'kpi-card';
    d.innerHTML = `<div class="kpi-v" style="color:${k.c}">${k.v}</div><div class="kpi-l">${k.l}</div><div class="kpi-s">${k.s}</div>`;
    kpis.appendChild(d);
  });

  // Rings
  const rings   = document.getElementById('an-rings');
  rings.innerHTML = '';
  const tT2     = ss.reduce((a, s) => a + (s.syllabus.topics || []).length, 0);
  const dT2     = ss.reduce((a, s) => a + (s.syllabus.topics || []).filter(x => x.done).length, 0);
  const asgnPct = tA ? Math.round(dA / tA * 100) : 0;
  const sylPct  = tT2 ? Math.round(dT2 / tT2 * 100) : 0;

  [
    { l: 'Assignment\nCompletion', p: asgnPct,   c: '#4ade80' },
    { l: 'Syllabus\nCoverage',     p: sylPct,    c: '#22d3ee' },
    { l: 'Quiz\nAverage',          p: gAvg ?? 0, c: '#facc15' },
  ].forEach(r => {
    const R2 = 36, C2 = 2 * Math.PI * R2, off = C2 - (r.p / 100) * C2;
    const d  = document.createElement('div');
    d.className = 'ring-item';
    d.innerHTML = `
      <div style="position:relative;width:86px;height:86px;">
        <svg style="transform:rotate(-90deg)" width="86" height="86" viewBox="0 0 86 86">
          <circle fill="none" cx="43" cy="43" r="${R2}" stroke-width="6" stroke="rgba(255,255,255,0.055)"/>
          <circle fill="none" cx="43" cy="43" r="${R2}" stroke-width="6" stroke="${r.c}" stroke-linecap="round" stroke-dasharray="${C2.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}"/>
        </svg>
        <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:14px;font-weight:800;color:${r.c};">${r.p}%</div>
      </div>
      <div class="ring-lbl">${r.l}</div>`;
    rings.appendChild(d);
  });

  // Upcoming reminders
  const remList = document.getElementById('an-reminders-list');
  if (remList) {
    const today    = new Date().toISOString().split('T')[0];
    const REMINDERS = _getReminders();
    const upcoming  = REMINDERS.filter(r => r.date >= today).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
    if (!upcoming.length) {
      remList.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,0.2);padding:6px 0;">No upcoming reminders — add one in Calendar!</div>';
    } else {
      remList.innerHTML = upcoming.map(r => {
        const d = daysUntil(r.date);
        const dayLbl = d === 0 ? 'TODAY' : d === 1 ? 'Tomorrow' : `${d}d away`;
        return `<div class="rem-item" style="margin-bottom:6px;"><div class="rem-item-icon">🔔</div><div class="rem-item-info"><div class="rem-item-title">${esc(r.title)}</div><div class="rem-item-sub">${fmtDate(r.date)}${r.time ? ' · ' + r.time : ''} — ${dayLbl}</div></div></div>`;
      }).join('');
    }
  }

  // Subject breakdown table
  const tbody = document.getElementById('an-tbody');
  tbody.innerHTML = '';
  if (!ss.length) {
    const r = document.createElement('tr');
    r.innerHTML = '<td colspan="6" style="text-align:center;color:rgba(255,255,255,0.2);padding:22px;">No subjects yet</td>';
    tbody.appendChild(r);
    updateStreak(); return;
  }

  ss.forEach(s => {
    const ta = s.assignments.length, da = s.assignments.filter(x => x.done).length;
    const ap = ta ? Math.round(da / ta * 100) : null;
    const qp = s.quizzes.filter(q => q.tot > 0).map(q => Math.round((q.obt / q.tot) * 100));
    const qa = qp.length ? Math.round(qp.reduce((a, b) => a + b, 0) / qp.length) : null;
    const tt = (s.syllabus.topics || []).length, dt = (s.syllabus.topics || []).filter(x => x.done).length;
    const sp = tt ? Math.round(dt / tt * 100) : null;

    const badge = (v, g, y) => v === null ? '<span class="badge n">—</span>' :
      v >= g ? `<span class="badge g">${v}${typeof g === 'number' && g <= 100 ? '%' : ''}</span>` :
      v >= y ? `<span class="badge y">${v}${typeof g === 'number' && g <= 100 ? '%' : ''}</span>` :
               `<span class="badge r">${v}${typeof g === 'number' && g <= 100 ? '%' : ''}</span>`;

    const qb = qa === null ? '<span class="badge n">—</span>' : qa >= 70 ? `<span class="badge g">${qa}%</span>` : qa >= 40 ? `<span class="badge y">${qa}%</span>` : `<span class="badge r">${qa}%</span>`;
    const ab = ap === null ? '<span class="badge n">—</span>' : ap === 100 ? `<span class="badge g">${da}/${ta}</span>` : ap >= 50 ? `<span class="badge y">${da}/${ta}</span>` : `<span class="badge r">${da}/${ta}</span>`;
    const sb = sp === null ? '<span class="badge n">—</span>' : sp >= 70 ? `<span class="badge g">${sp}%</span>` : sp >= 30 ? `<span class="badge y">${sp}%</span>` : `<span class="badge r">${sp}%</span>`;

    const r = document.createElement('tr');
    r.innerHTML = `<td style="cursor:pointer;" onclick="window._openSubject('${s.id}')">${s.icon} <strong>${esc(s.name)}</strong></td><td>${s.notes.length}</td><td>${ab}</td><td>${s.quizzes.length}</td><td>${qb}</td><td>${sb}</td>`;
    tbody.appendChild(r);
  });

  updateStreak();
}

// ── STREAK ────────────────────────────────────────────────────────────────────
export function updateStreak() {
  const log   = D.studyLog || [];
  // BUG FIX: use local date consistently to avoid timezone mismatch
  const dates = new Set(log.map(l => {
    const d = new Date(l.date);
    return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  }));

  const toKey = (d) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  let streak = 0;
  const d = new Date();

  // Allow streak if last session was today or yesterday
  if (!dates.has(toKey(d))) { d.setDate(d.getDate() - 1); }
  while (dates.has(toKey(d))) { streak++; d.setDate(d.getDate() - 1); }

  const el = document.getElementById('streak-count');
  if (el) el.textContent = streak;
}

function _getReminders() {
  try { return JSON.parse(localStorage.getItem('sv4_reminders') || '[]'); } catch { return []; }
}

// Expose for analytics table clicks
window._openSubject = (id) => import('./subjects.js').then(m => m.openSubject(id));
