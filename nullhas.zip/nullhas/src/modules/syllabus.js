// ── SYLLABUS MODULE ───────────────────────────────────────────────────────────
import { getSub } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { openModal, closeModal, showUndo } from '../ui/modals.js';
import { toast } from '../ui/toast.js';
import { uid, esc } from '../utils/helpers.js';
import { ICONS } from '../ui/icons.js';
import { setTabCnt, updateHeroQS } from './subjects.js';

export function renderSyllabus() {
  const s = getSub(); if (!s) return;
  document.getElementById('syl-text').value = s.syllabus.text || '';

  const topics = s.syllabus.topics || [];
  const done   = topics.filter(t => t.done).length;
  const pct    = topics.length ? Math.round(done / topics.length * 100) : 0;

  document.getElementById('topic-cnt').textContent = topics.length;
  setTabCnt('syllabus', `${done}/${topics.length}`);
  document.getElementById('syl-arc-pct').textContent = pct + '%';

  const R = 31, C = 2 * Math.PI * R, offset = C - (pct / 100) * C;
  const arcFg = document.getElementById('arc-fg');
  if (arcFg) {
    arcFg.setAttribute('stroke', `rgba(${s.cr},${s.cg},${s.cb},0.75)`);
    arcFg.setAttribute('stroke-dasharray', C.toFixed(1));
    arcFg.setAttribute('stroke-dashoffset', offset.toFixed(1));
  }

  document.getElementById('syl-cov-title').textContent = topics.length
    ? `${done} of ${topics.length} topics covered`
    : 'No topics added';
  document.getElementById('syl-cov-sub').textContent = topics.length
    ? `${pct}% syllabus complete`
    : 'Add topics to track coverage';

  const list = document.getElementById('topic-list');
  if (!topics.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-emoji">📚</div><div class="empty-msg">No topics added yet</div></div>`;
    return;
  }

  list.innerHTML = '';
  topics.forEach((t, i) => {
    const revBadge = t.needsRevision && !t.done
      ? `<span class="topic-status needs-revision">Revision</span>` : '';
    const el = document.createElement('div');
    el.className = 'topic-item' + (t.done ? ' done' : '');
    el.innerHTML = `
      <div class="topic-num">${i + 1}</div>
      <div class="topic-cb${t.done ? ' on' : ''}" onclick="window._toggleTopic('${t.id}')">
        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
      </div>
      <div class="topic-text">${esc(t.title)}</div>
      ${revBadge}
      <div class="item-btns">
        <div class="item-btn edit" onclick="window._toggleRevision('${t.id}')" title="Mark for revision">
          <svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.06"/></svg>
        </div>
        <div class="item-btn del" onclick="window._delTopic('${t.id}')">${ICONS.trash}</div>
      </div>`;
    list.appendChild(el);
  });
}

export function openTopicModal() {
  document.getElementById('ti-name').value = '';
  openModal('modal-topic');
}

export function saveTopic() {
  const title = document.getElementById('ti-name').value.trim();
  if (!title) { toast('Please enter a topic name!'); return; }
  const s = getSub(); if (!s) { toast('No subject selected!'); return; }
  if (!s.syllabus.topics) s.syllabus.topics = [];
  s.syllabus.topics.push({ id: uid(), title, done: false, needsRevision: false });
  persist(); renderSyllabus(); closeModal('modal-topic'); toast('Topic added');
}

export function toggleTopic(id) {
  const s = getSub(); if (!s) return;
  const t = (s.syllabus.topics || []).find(x => x.id === id); if (!t) return;
  t.done = !t.done;
  persist(); renderSyllabus(); updateHeroQS();
}

export function toggleTopicRevision(id) {
  const s = getSub(); if (!s) return;
  const t = (s.syllabus.topics || []).find(x => x.id === id); if (!t) return;
  t.needsRevision = !t.needsRevision;
  persist(); renderSyllabus();
  toast(t.needsRevision ? 'Marked for revision 🔄' : 'Revision cleared');
}

export function delTopicWithUndo(id) {
  const s   = getSub(); if (!s) return;
  const idx = s.syllabus.topics.findIndex(t => t.id === id); if (idx < 0) return;
  const backup = JSON.parse(JSON.stringify(s.syllabus.topics[idx]));
  s.syllabus.topics.splice(idx, 1);
  persist(); renderSyllabus();
  showUndo('Topic deleted', () => { s.syllabus.topics.splice(idx, 0, backup); persist(); renderSyllabus(); });
}

export function saveSyllabus() {
  const s = getSub(); if (!s) return;
  s.syllabus.text = document.getElementById('syl-text').value;
  persist(); toast('Syllabus saved! 📋');
}

// ── GLOBAL BINDINGS ───────────────────────────────────────────────────────────
window._toggleTopic    = toggleTopic;
window._toggleRevision = toggleTopicRevision;
window._delTopic       = (id) => delTopicWithUndo(id);
