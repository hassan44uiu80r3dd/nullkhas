// ── FLOATING ACTION BUTTON ────────────────────────────────────────────────────
import { fabOpen, setFabOpen } from '../data/store.js';

export function toggleFab() {
  const next = !fabOpen;
  setFabOpen(next);
  const fab = document.getElementById('fab');
  const menu = document.getElementById('fab-menu');
  fab?.classList.toggle('open', next);
  menu?.classList.toggle('open', next);
  fab?.setAttribute('aria-expanded', String(next));
}

export function closeFab() {
  setFabOpen(false);
  const fab = document.getElementById('fab');
  const menu = document.getElementById('fab-menu');
  fab?.classList.remove('open');
  menu?.classList.remove('open');
  fab?.setAttribute('aria-expanded', 'false');
}

export function fabAddSubject() {
  closeFab();
  import('./subjects.js').then(m => m.openAddSubject());
}

export function fabAddNote() {
  closeFab();
  import('./notes.js').then(m => m.openNoteModal());
}

export function fabAddAsgn() {
  closeFab();
  import('./assignments.js').then(m => m.openAsgnModal());
}

export function fabAddQuiz() {
  closeFab();
  import('./quiz.js').then(m => m.openQuizModal());
}
