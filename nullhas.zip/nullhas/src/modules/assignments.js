// ── ASSIGNMENTS MODULE ────────────────────────────────────────────────────────
import { D, getSub } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { dbSet, dbGet, dbDel } from '../storage/idb.js';
import { openModal, closeModal, confirmDelete, showUndo } from '../ui/modals.js';
import { toast } from '../ui/toast.js';
import { uid, esc, fmtDate, daysUntil } from '../utils/helpers.js';
import { ICONS } from '../ui/icons.js';
import { setTabCnt, updateHeroQS } from './subjects.js';

let asgnFilter = 'all';
export function setAsgnFilter(f) { asgnFilter = f; }

export function renderAsgn() {
  const s   = getSub(); if (!s) return;
  const all = s.assignments;
  document.getElementById('asgn-cnt').textContent = all.length;
  setTabCnt('assignments', all.length);

  const done = all.filter(a => a.done).length;
  const pct  = all.length ? Math.round(done / all.length * 100) : 0;
  document.getElementById('asgn-pct').textContent = pct + '%';
  document.getElementById('asgn-fill').style.width = pct + '%';

  // Update filter buttons
  document.querySelectorAll('.af-btn').forEach(b => b.classList.toggle('on', b.dataset.f === asgnFilter));

  const today = new Date(); today.setHours(0,0,0,0);
  let filtered = all.filter(a => {
    if (asgnFilter === 'pending') return !a.done;
    if (asgnFilter === 'overdue') return !a.done && daysUntil(a.due) !== null && daysUntil(a.due) < 0;
    if (asgnFilter === 'done')    return a.done;
    return true;
  });

  const list = document.getElementById('asgn-list');
  if (!filtered.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-emoji">✅</div><div class="empty-msg">No assignments</div><div class="empty-hint">${asgnFilter === 'done' ? 'Complete some assignments first' : 'Add your first assignment'}</div></div>`;
    return;
  }

  // Sort: overdue first, then by due date, then done at bottom
  filtered = [...filtered].sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    const da = daysUntil(a.due), db = daysUntil(b.due);
    if (da === null && db === null) return 0;
    if (da === null) return 1;
    if (db === null) return -1;
    return da - db;
  });

  list.innerHTML = '';
  filtered.forEach(a => {
    const d     = daysUntil(a.due);
    const badge = _dueBadge(d, a.done);
    const typeLabel = { homework:'HW', lab:'LAB', project:'PROJECT', presentation:'PRES', other:'OTHER' };
    const phaseCls  = a.phaseOverride ? `phase-${a.phaseOverride}` : '';
    const subtasks  = (a.subtasks || []);
    const stDone    = subtasks.filter(st => st.done).length;
    const stHtml    = subtasks.length ? `<div class="subtask-list">${subtasks.map(st => `<div class="subtask-item ${st.done ? 'done' : ''}" onclick="window._toggleSubtask('${a.id}','${st.id}')">${ICONS.check} ${esc(st.title)}</div>`).join('')}</div>` : '';
    const marksHtml = (a.obt !== undefined && a.tot) ? `<div class="asgn-marks"><span class="asgn-marks-val">${a.obt}/${a.tot}</span> <span class="asgn-marks-lbl">marks</span></div>` : '';

    const el = document.createElement('div');
    el.className = `asgn-item ${a.done ? 'done' : ''} ${phaseCls}`;
    el.innerHTML = `
      <div class="asgn-check ${a.done ? 'on' : ''}" onclick="window._toggleAsgn('${a.id}')">
        ${a.done ? ICONS.check : ''}
      </div>
      <div class="asgn-body">
        <div class="asgn-title">${esc(a.title)}</div>
        <div class="asgn-meta-row">
          <span class="asgn-type-badge">${typeLabel[a.type] || 'HW'}</span>
          ${a.due ? badge : ''}
          ${marksHtml}
        </div>
        ${a.notes ? `<div class="asgn-notes-txt">${esc(a.notes)}</div>` : ''}
        ${stHtml}
      </div>
      <div class="item-btns">
        ${a.fileId ? `<div class="item-btn" onclick="window._viewFile('${a.id}')" title="View file">${ICONS.paperclip}</div>` : ''}
        <div class="item-btn edit" onclick="window._editAsgn('${a.id}')">${ICONS.edit}</div>
        <div class="item-btn del"  onclick="window._delAsgn('${a.id}')">${ICONS.trash}</div>
      </div>`;
    list.appendChild(el);
  });
}

function _dueBadge(d, done) {
  if (done || d === null) return '';
  const txt = d < 0 ? 'Overdue' : d === 0 ? 'Due Today' : d === 1 ? 'Due Tomorrow' : `${d}d left`;
  const cls = d < 0 ? 'overdue' : d <= 1 ? 'soon' : '';
  return `<span class="asgn-due-badge ${cls}">${txt}</span>`;
}

// ── DUE ALERTS (Home page) ────────────────────────────────────────────────────
export function renderDueAlerts() {
  const wrap = document.getElementById('due-alerts-wrap'); if (!wrap) return;
  const all  = [];
  D.subjects.forEach(s => s.assignments.forEach(a => {
    if (a.done) return;
    const d = daysUntil(a.due);
    if (d === null) return;
    if (d < 0)    all.push({ type:'overdue', title:a.title, sub:s.name, days:d });
    else if (d <= 2) all.push({ type:'soon', title:a.title, sub:s.name, days:d });
  }));

  if (!all.length) { wrap.innerHTML = ''; wrap.style.display = 'none'; return; }
  wrap.style.display      = 'flex';
  wrap.style.flexDirection = 'column';
  wrap.style.gap           = '8px';
  wrap.innerHTML           = '';

  all.slice(0, 3).forEach(it => {
    const badge = it.days < 0 ? 'Overdue' : it.days === 0 ? 'Due Today' : it.days === 1 ? 'Due Tomorrow' : it.days + 'd left';
    const el = document.createElement('div');
    el.className = 'due-alert-card' + (it.type === 'soon' ? ' warn' : '');
    el.innerHTML = `<div class="due-alert-icon">${it.type === 'overdue' ? '🚨' : '⏰'}</div><div class="due-alert-info"><div class="due-alert-title">${esc(it.title)}</div><div class="due-alert-sub">${esc(it.sub)}</div></div><div class="due-alert-badge">${badge}</div>`;
    wrap.appendChild(el);
  });
}

// ── MODAL ─────────────────────────────────────────────────────────────────────
let _editAsgnId = null;
let _subtaskInputs = [];

export function openAsgnModal(editId = null) {
  _editAsgnId = editId;
  const s    = getSub();
  const asgn = editId ? s?.assignments.find(a => a.id === editId) : null;

  document.getElementById('ai-title').value = asgn?.title || '';
  document.getElementById('ai-due').value   = asgn?.due   || '';
  document.getElementById('ai-type').value  = asgn?.type  || 'homework';
  document.getElementById('ai-notes').value = asgn?.notes || '';
  document.getElementById('ai-obt').value   = asgn?.obt ?? '';
  document.getElementById('ai-tot').value   = asgn?.tot ?? '';
  document.getElementById('ai-phase-override').value = asgn?.phaseOverride || '';
  document.getElementById('ai-file-lbl').textContent = asgn?.fileName || 'Choose PDF or DOCX...';
  document.getElementById('asgn-modal-title').childNodes[0].textContent = editId ? 'Edit Assignment' : 'Add Assignment';
  document.getElementById('asgn-save-btn').textContent = editId ? 'Update Assignment' : 'Add Assignment';

  // Subtasks
  _subtaskInputs = (asgn?.subtasks || []).map(st => ({ ...st }));
  _renderSubtaskInputs();

  openModal('modal-asgn');
  setTimeout(() => document.getElementById('ai-title').focus(), 200);
}

function _renderSubtaskInputs() {
  const list = document.getElementById('subtask-input-list');
  if (!list) return;
  list.innerHTML = '';
  _subtaskInputs.forEach((st, i) => {
    const d = document.createElement('div');
    d.className = 'subtask-input-row';
    d.innerHTML = `<span>${esc(st.title)}</span><span class="tag-remove" onclick="window._removeSubtaskInput(${i})">×</span>`;
    list.appendChild(d);
  });
}

export function addSubtaskInput() {
  const inp = document.getElementById('subtask-input');
  const val = inp.value.trim();
  if (!val) return;
  _subtaskInputs.push({ id: uid(), title: val, done: false });
  inp.value = '';
  _renderSubtaskInputs();
}

export function saveAsgn() {
  const s = getSub(); if (!s) { toast('No subject selected!'); return; }
  const title = document.getElementById('ai-title').value.trim();
  if (!title) { toast('Please enter a title!'); return; }

  const obt = parseFloat(document.getElementById('ai-obt').value);
  const tot = parseFloat(document.getElementById('ai-tot').value);

  const data = {
    title,
    due:           document.getElementById('ai-due').value,
    type:          document.getElementById('ai-type').value,
    notes:         document.getElementById('ai-notes').value.trim(),
    obt:           isNaN(obt) ? undefined : obt,
    tot:           isNaN(tot) ? undefined : tot,
    phaseOverride: document.getElementById('ai-phase-override').value || '',
    subtasks:      _subtaskInputs,
  };

  if (_editAsgnId) {
    const a = s.assignments.find(x => x.id === _editAsgnId);
    if (a) Object.assign(a, data);
    toast('Assignment updated! ✏️');
  } else {
    s.assignments.push({ id: uid(), done: false, ...data });
    toast('Assignment added! ✅');
  }

  persist(); renderAsgn(); updateHeroQS(); closeModal('modal-asgn'); _editAsgnId = null;
}

export function toggleAsgn(id) {
  const s = getSub(); if (!s) return;
  const a = s.assignments.find(x => x.id === id); if (!a) return;
  a.done = !a.done;
  persist(); renderAsgn(); updateHeroQS();
}

export function toggleSubtask(asgnId, stId) {
  const s = getSub(); if (!s) return;
  const a = s.assignments.find(x => x.id === asgnId); if (!a) return;
  const st = (a.subtasks || []).find(x => x.id === stId); if (!st) return;
  st.done = !st.done;
  persist(); renderAsgn();
}

export function delAsgnWithUndo(id) {
  const s   = getSub(); if (!s) return;
  const idx = s.assignments.findIndex(a => a.id === id); if (idx < 0) return;
  const backup = JSON.parse(JSON.stringify(s.assignments[idx]));
  s.assignments.splice(idx, 1);
  persist(); renderAsgn(); updateHeroQS();
  showUndo('Assignment deleted', () => {
    s.assignments.splice(idx, 0, backup);
    persist(); renderAsgn(); updateHeroQS();
  });
}

// ── FILE HANDLING ─────────────────────────────────────────────────────────────
export async function onFileSelect(input) {
  const file = input.files[0]; if (!file) return;
  const ALLOWED = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
  if (!ALLOWED.includes(file.type) && !file.name.match(/\.(pdf|docx)$/i)) {
    toast('⚠️ Only PDF and DOCX files are supported');
    input.value = '';
    return;
  }
  if (file.size > 5 * 1024 * 1024) { toast('⚠️ File too large (max 5MB)'); input.value = ''; return; }
  const reader = new FileReader();
  reader.onload = async e => {
    const fileId = uid();
    await dbSet(fileId, e.target.result);
    document.getElementById('ai-file-lbl').textContent = file.name;
    document.getElementById('ai-file').dataset.fileId   = fileId;
    document.getElementById('ai-file').dataset.fileName = file.name;
    document.getElementById('ai-file').dataset.fileType = file.type;
  };
  reader.readAsDataURL(file);
}

export async function viewFile(asgnId) {
  const s = getSub(); if (!s) return;
  const a = s.assignments.find(x => x.id === asgnId); if (!a?.fileId) return;
  const b64 = await dbGet(a.fileId);
  if (!b64) { toast('File not found — please re-attach it.'); return; }
  document.getElementById('fv-fn').textContent = a.fileName || 'Document';
  document.getElementById('fv-body').innerHTML = '<div class="fv-loading">⏳ Loading...</div>';
  document.getElementById('fv-nav').style.display = 'none';
  openModal('modal-fv');
  try {
    if ((a.fileType || '').includes('pdf') || a.fileName?.endsWith('.pdf')) {
      await import('./fileViewer.js').then(m => m.showPDF(b64));
    } else if (a.fileName?.endsWith('.docx')) {
      await import('./fileViewer.js').then(m => m.showDOCX(b64));
    } else {
      document.getElementById('fv-body').innerHTML = '<div class="fv-err">⚠️ Unsupported file type.</div>';
    }
  } catch (e) {
    document.getElementById('fv-body').innerHTML = `<div class="fv-err">⚠️ Could not load file: ${e.message}</div>`;
  }
}

// ── GLOBAL BINDINGS ───────────────────────────────────────────────────────────
window._toggleAsgn      = toggleAsgn;
window._toggleSubtask   = toggleSubtask;
window._editAsgn        = (id) => openAsgnModal(id);
window._delAsgn         = (id) => confirmDelete('Delete assignment?', 'This cannot be undone.', () => delAsgnWithUndo(id));
window._viewFile        = viewFile;
window._removeSubtaskInput = (i) => { _subtaskInputs.splice(i, 1); _renderSubtaskInputs(); };
