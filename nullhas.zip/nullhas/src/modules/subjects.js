// ── SUBJECTS MODULE ───────────────────────────────────────────────────────────
import { D, CID, setCID, getSub, selEm, selCol, setSelEm, setSelCol, editSubSelEm, editSubSelCol, setEditSubSelEm, setEditSubSelCol } from '../data/store.js';
import { EMOJIS, COLS } from '../data/defaults.js';
import { ICONS } from '../ui/icons.js';
import { persist } from '../storage/persist.js';
import { openModal, closeModal, confirmDelete, showUndo } from '../ui/modals.js';
import { toast } from '../ui/toast.js';
import { uid, esc, daysUntil } from '../utils/helpers.js';
import { showView } from '../ui/views.js';
import { renderGreeting } from './analytics.js';

export function renderDash() {
  const g = document.getElementById('sub-grid');
  if (!g) return;
  document.getElementById('dash-meta').textContent = D.subjects.length + ' subject' + (D.subjects.length !== 1 ? 's' : '');
  g.innerHTML = '';

  if (!D.subjects.length) {
    const onb = document.createElement('div');
    onb.style.cssText = 'grid-column:1/-1;';
    onb.innerHTML = `<div class="onboard-wrap"><div class="onboard-icon">📚</div><div class="onboard-title">Welcome to nullHas</div><div class="onboard-sub">Add your first subject to get started. Notes, assignments, and quizzes — all in one place.</div><button class="onboard-btn empty-cta" onclick="window._openAddSubject()">Add First Subject</button></div>`;
    g.appendChild(onb);
    return;
  }

  D.subjects.forEach(s => {
    const dA      = s.assignments.filter(a => a.done).length;
    const tA      = s.assignments.length;
    const overdue = s.assignments.filter(a => !a.done && daysUntil(a.due) < 0).length;
    const c       = document.createElement('div');
    c.className   = 'sub-card';
    c.style.cssText = `--cr:${s.cr};--cg:${s.cg};--cb:${s.cb};`;
    c.innerHTML = `
      <div class="sub-card-top">
        <div class="sub-icon-wrap" style="background:rgba(${s.cr},${s.cg},${s.cb},0.12);border:1px solid rgba(${s.cr},${s.cg},${s.cb},0.22);">${s.icon}</div>
        <div class="sub-actions">
          <div class="sub-action-btn" onclick="event.stopPropagation();window._openEditSubject('${s.id}')">${ICONS.edit}</div>
          <div class="sub-action-btn" onclick="event.stopPropagation();window._confirmDelSubject('${s.id}')">${ICONS.trash}</div>
        </div>
      </div>
      <div class="sub-name">${esc(s.name)}</div>
      <div class="sub-code">${s.code ? esc(s.code) : '&nbsp;'}</div>
      <div class="sub-stats">
        <div class="stat-chip">${ICONS.notes} ${s.notes.length}</div>
        ${tA ? `<div class="stat-chip accent">${ICONS.check} ${dA}/${tA}</div>` : `<div class="stat-chip">${ICONS.check} 0</div>`}
        ${overdue ? `<div class="stat-chip" style="background:rgba(248,113,113,0.1);border-color:rgba(248,113,113,0.22);color:#f87171;">${ICONS.alertCircle} ${overdue}</div>` : ''}
      </div>`;
    c.addEventListener('click', () => openSubject(s.id));
    g.appendChild(c);
  });

  const add = document.createElement('div');
  add.className = 'add-card';
  add.onclick = openAddSubject;
  add.innerHTML = '<div class="add-card-icon">＋</div><div class="add-card-lbl">New Subject</div>';
  g.appendChild(add);
}

// ── ADD SUBJECT ──────────────────────────────────────────────────────────────
export function openAddSubject() {
  const eg = document.getElementById('em-grid');
  eg.innerHTML = '';
  EMOJIS.forEach(e => {
    const d = document.createElement('div');
    d.className = 'em-opt' + (e === selEm ? ' on' : '');
    d.innerHTML = e;
    d.onclick = () => { setSelEm(e); document.querySelectorAll('.em-opt').forEach(x => x.classList.remove('on')); d.classList.add('on'); };
    eg.appendChild(d);
  });
  const cg = document.getElementById('col-grid');
  cg.innerHTML = '';
  COLS.forEach(c => {
    const d = document.createElement('div');
    d.className = 'col-opt' + (c === selCol ? ' on' : '');
    d.style.background = c.hex;
    d.onclick = () => { setSelCol(c); document.querySelectorAll('.col-opt').forEach(x => x.classList.remove('on')); d.classList.add('on'); };
    cg.appendChild(d);
  });
  document.getElementById('si-name').value  = '';
  document.getElementById('si-code').value  = '';
  openModal('modal-subject');
  setTimeout(() => document.getElementById('si-name').focus(), 200);
}

export function saveSubject() {
  const name = document.getElementById('si-name').value.trim();
  if (!name) { toast('Please enter a subject name!'); return; }
  D.subjects.push({
    id: uid(), name,
    code: document.getElementById('si-code').value.trim(),
    icon: selEm, cr: selCol.r, cg: selCol.g, cb: selCol.b,
    notes: [], assignments: [], quizzes: [],
    syllabus: { text: '', topics: [] }
  });
  persist(); renderDash(); closeModal('modal-subject'); toast('Subject created'); renderGreeting();
}

// ── EDIT SUBJECT ─────────────────────────────────────────────────────────────
export function openEditSubject(id) {
  const s = D.subjects.find(x => x.id === id);
  if (!s) return;
  document.getElementById('edit-sub-id').value   = id;
  document.getElementById('edit-sub-name').value = s.name;
  document.getElementById('edit-sub-code').value = s.code || '';
  setEditSubSelEm(s.icon || '📖');
  setEditSubSelCol(COLS.find(c => c.r === s.cr && c.g === s.cg && c.b === s.cb) || { r: s.cr, g: s.cg, b: s.cb, hex: `rgb(${s.cr},${s.cg},${s.cb})` });

  const eg = document.getElementById('edit-em-grid');
  eg.innerHTML = '';
  EMOJIS.forEach(e => {
    const d = document.createElement('div');
    d.className = 'em-opt' + (e === editSubSelEm ? ' on' : '');
    d.innerHTML = e;
    d.onclick = () => { setEditSubSelEm(e); document.querySelectorAll('#edit-em-grid .em-opt').forEach(x => x.classList.remove('on')); d.classList.add('on'); };
    eg.appendChild(d);
  });
  const cg = document.getElementById('edit-col-grid');
  cg.innerHTML = '';
  COLS.forEach(c => {
    const d = document.createElement('div');
    d.className = 'col-opt' + (c.r === s.cr && c.g === s.cg && c.b === s.cb ? ' on' : '');
    d.style.background = c.hex;
    d.onclick = () => { setEditSubSelCol(c); document.querySelectorAll('#edit-col-grid .col-opt').forEach(x => x.classList.remove('on')); d.classList.add('on'); };
    cg.appendChild(d);
  });
  openModal('modal-edit-subject');
  setTimeout(() => document.getElementById('edit-sub-name').focus(), 200);
}

export function saveEditSubject() {
  const id   = document.getElementById('edit-sub-id').value;
  const name = document.getElementById('edit-sub-name').value.trim();
  if (!name) { toast('Please enter a subject name!'); return; }
  const s = D.subjects.find(x => x.id === id);
  if (!s) return;
  s.name = name;
  s.code = document.getElementById('edit-sub-code').value.trim();
  s.icon = editSubSelEm;
  s.cr   = editSubSelCol.r;
  s.cg   = editSubSelCol.g;
  s.cb   = editSubSelCol.b;
  persist(); renderDash(); closeModal('modal-edit-subject'); toast('Subject updated');
  if (CID === id) {
    document.getElementById('sh-icon').innerHTML  = s.icon;
    document.getElementById('sh-name').textContent = s.name;
    document.getElementById('sh-code').textContent = s.code || '';
  }
}

// ── DELETE SUBJECT ───────────────────────────────────────────────────────────
export function delSubjectWithUndo(id) {
  const idx = D.subjects.findIndex(s => s.id === id);
  if (idx < 0) return;
  const backup = JSON.parse(JSON.stringify(D.subjects[idx]));
  D.subjects.splice(idx, 1);

  // FIX: navigate away if we're in the deleted subject
  if (CID === id) {
    setCID(null);
    showView('subjects');
  }
  persist();
  renderDash();

  showUndo(`"${backup.name}" deleted`, () => {
    D.subjects.splice(Math.min(idx, D.subjects.length), 0, backup);
    persist();
    renderDash();
  });
}

// ── OPEN SUBJECT ─────────────────────────────────────────────────────────────
export function openSubject(id) {
  setCID(id);
  const s = getSub();
  if (!s) { toast('Subject not found.'); setCID(null); showView('subjects'); return; }

  import('../modules/notes.js').then(m => { m.setNoteFilter('all'); });
  import('../modules/assignments.js').then(m => { m.setAsgnFilter('all'); });

  _applySubjectVars(s);
  const shIcon = document.getElementById('sh-icon');
  shIcon.innerHTML = s.icon;
  shIcon.style.cssText = `background:rgba(${s.cr},${s.cg},${s.cb},0.12);border:1px solid rgba(${s.cr},${s.cg},${s.cb},0.25);`;
  document.getElementById('sh-name').textContent = s.name;
  document.getElementById('sh-code').textContent = s.code || '';
  document.title = 'nullHas — ' + s.name;

  updateHeroQS();
  _buildTabs();
  switchTab('notes');

  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById('view-detail').classList.add('active');
  const fn = document.getElementById('fab-note');
  const fa = document.getElementById('fab-asgn');
  const fq = document.getElementById('fab-quiz');
  if (fn) fn.style.display = '';
  if (fa) fa.style.display = '';
  if (fq) fq.style.display = '';
  renderAll();
}

function _applySubjectVars(s) {
  const el = document.getElementById('view-detail');
  el.style.setProperty('--cr', s.cr);
  el.style.setProperty('--cg', s.cg);
  el.style.setProperty('--cb', s.cb);
  el.style.setProperty('--sc', `rgb(${s.cr},${s.cg},${s.cb})`);
}

function _buildTabs() {
  const tabs = [
    { key:'notes',       em: ICONS.notes, lbl:'Notes'       },
    { key:'assignments', em: ICONS.check, lbl:'Assignments'  },
    { key:'quiz',        em: ICONS.flask, lbl:'Quizzes'      },
    { key:'syllabus',    em: ICONS.list,  lbl:'Syllabus'     },
  ];
  const pt = document.getElementById('ptabs');
  pt.innerHTML = '';
  tabs.forEach((t, i) => {
    const d = document.createElement('div');
    d.className = 'ptab' + (i === 0 ? ' on' : '');
    d.dataset.key = t.key;
    d.innerHTML = `<div class="ptab-emoji">${t.em}</div><div class="ptab-info"><div class="ptab-label">${t.lbl}</div><div class="ptab-cnt" id="ptab-cnt-${t.key}">—</div></div><div class="ptab-bar"></div>`;
    d.onclick = () => switchTab(t.key);
    pt.appendChild(d);
  });
}

export function switchTab(key) {
  document.querySelectorAll('.ptab').forEach(t => t.classList.toggle('on', t.dataset.key === key));
  document.querySelectorAll('.tab-panel').forEach(p => { p.classList.remove('on'); if (p.id === 'panel-' + key) p.classList.add('on'); });
}

export function setTabCnt(key, n) {
  const el = document.getElementById('ptab-cnt-' + key);
  if (el) el.textContent = n;
}

export function updateHeroQS() {
  const s = getSub(); if (!s) return;
  const dA = s.assignments.filter(a => a.done).length, tA = s.assignments.length;
  const qPcts = s.quizzes.filter(q => q.tot > 0).map(q => Math.round((q.obt / q.tot) * 100));
  const qAvg  = qPcts.length ? Math.round(qPcts.reduce((a, b) => a + b, 0) / qPcts.length) : null;
  const tT    = (s.syllabus.topics || []).length;
  const dT    = (s.syllabus.topics || []).filter(t => t.done).length;
  document.getElementById('sh-qs').innerHTML = `
    <div class="sh-qs"><div class="sh-qs-val">${s.notes.length}</div><div class="sh-qs-lbl">Notes</div></div>
    <div class="sh-qs"><div class="sh-qs-val">${dA}/${tA}</div><div class="sh-qs-lbl">Done</div></div>
    <div class="sh-qs"><div class="sh-qs-val">${qAvg !== null ? qAvg + '%' : '—'}</div><div class="sh-qs-lbl">Quiz Avg</div></div>
    <div class="sh-qs"><div class="sh-qs-val">${tT ? dT + '/' + tT : '0'}</div><div class="sh-qs-lbl">Topics</div></div>`;
}

export function renderAll() {
  Promise.all([
    import('./notes.js').then(m => m.renderNotes()),
    import('./assignments.js').then(m => m.renderAsgn()),
    import('./quiz.js').then(m => m.renderQuiz()),
    import('./syllabus.js').then(m => m.renderSyllabus()),
  ]);
}

// ── GLOBAL BINDINGS ───────────────────────────────────────────────────────────
window._openAddSubject    = openAddSubject;
window._openEditSubject   = openEditSubject;
window._confirmDelSubject = (id) => confirmDelete('Delete this subject?', 'All data will be permanently removed.', () => delSubjectWithUndo(id));
