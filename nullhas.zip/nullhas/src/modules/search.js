// ── SEARCH MODULE ─────────────────────────────────────────────────────────────
import { D } from '../data/store.js';
import { esc } from '../utils/helpers.js';
import { showView } from '../ui/views.js';

export function toggleSearch() {
  const panel  = document.getElementById('search-panel');
  const isOpen = panel.style.display !== 'none';
  panel.style.display = isOpen ? 'none' : 'block';
  if (!isOpen) {
    document.getElementById('search-input').focus();
    document.getElementById('search-results').innerHTML = '';
  }
}

export function doSearch(q) {
  const results = document.getElementById('search-results');
  if (!q.trim()) { results.innerHTML = ''; return; }
  const qL    = q.toLowerCase();
  const items = [];

  D.subjects.forEach(s => {
    if (s.name.toLowerCase().includes(qL) || s.code?.toLowerCase().includes(qL)) {
      items.push({ icon: s.icon, title: s.name, sub: s.code || 'Subject', type: 'Subject',
        action: () => { toggleSearch(); import('./subjects.js').then(m => m.openSubject(s.id)); }
      });
    }

    s.notes.forEach(n => {
      const contentText  = (n.html || '').replace(/<[^>]+>/g, ' ');
      const contentMatch = contentText.toLowerCase().includes(qL);
      if (n.title.toLowerCase().includes(qL) || contentMatch) {
        const preview = contentText.replace(/\s+/g, ' ').trim().slice(0, 60);
        // BUG FIX: capture IDs not refs — re-look up at click time to avoid stale refs
        const subId = s.id, noteId = n.id;
        items.push({ icon: '📝', title: n.title, sub: s.name + (preview ? ' · ' + preview : ''), type: 'Note',
          action: () => {
            toggleSearch();
            import('./subjects.js').then(m => m.openSubject(subId)).then(() => {
              import('./notes.js').then(nm => nm.openReadNote(noteId));
            });
          }
        });
      }
    });

    s.assignments.forEach(a => {
      if (a.title.toLowerCase().includes(qL)) {
        items.push({ icon: '✅', title: a.title, sub: s.name, type: 'Assignment',
          action: () => { toggleSearch(); import('./subjects.js').then(m => m.openSubject(s.id)); }
        });
      }
    });

    s.quizzes.forEach(qz => {
      if (qz.name.toLowerCase().includes(qL)) {
        items.push({ icon: '🧪', title: qz.name, sub: s.name, type: 'Quiz',
          action: () => { toggleSearch(); import('./subjects.js').then(m => m.openSubject(s.id)); }
        });
      }
    });
  });

  if (!items.length) {
    results.innerHTML = `<div class="search-empty">No results for "${esc(q)}"</div>`;
    return;
  }

  results.innerHTML = '';
  items.slice(0, 12).forEach(it => {
    const d = document.createElement('div');
    d.className = 'search-result-item';
    d.innerHTML = `<div class="sr-icon">${it.icon}</div><div class="sr-body"><div class="sr-title">${esc(it.title)}</div><div class="sr-sub">${esc(it.sub)}</div></div><div class="sr-type">${it.type}</div>`;
    d.onclick = it.action;
    results.appendChild(d);
  });
}
