// ── FILE VIEWER ───────────────────────────────────────────────────────────────
import { setPdfDoc, setPdfPg, setPdfTot, pdfDoc, pdfPg, pdfTot } from '../data/store.js';

export async function showPDF(b64) {
  // pdfjsLib loaded via CDN script tag
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const bin  = atob(b64.split(',')[1]);
  const arr  = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  const doc  = await pdfjsLib.getDocument({ data: arr }).promise;
  setPdfDoc(doc);
  setPdfTot(doc.numPages);
  setPdfPg(1);
  await renderPDFPage(1);
  if (doc.numPages > 1) document.getElementById('fv-nav').style.display = 'flex';
}

export async function renderPDFPage(n) {
  document.getElementById('fv-body').innerHTML = '<div class="fv-loading">Rendering...</div>';
  const page   = await pdfDoc.getPage(n);
  const vp     = page.getViewport({ scale: window.innerWidth < 640 ? 1.0 : 1.5 });
  const canvas = document.createElement('canvas');
  canvas.width  = vp.width;
  canvas.height = vp.height;
  await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
  const wrap = document.createElement('div');
  wrap.className = 'fv-pdf-wrap';
  wrap.appendChild(canvas);
  document.getElementById('fv-body').innerHTML = '';
  document.getElementById('fv-body').appendChild(wrap);
  document.getElementById('fv-pg').textContent = `Page ${n} of ${pdfTot}`;
}

export async function pdfPrev() { if (pdfPg > 1)       { setPdfPg(pdfPg - 1); await renderPDFPage(pdfPg); } }
export async function pdfNext() { if (pdfPg < pdfTot)  { setPdfPg(pdfPg + 1); await renderPDFPage(pdfPg); } }

export async function showDOCX(b64) {
  const bin  = atob(b64.split(',')[1]);
  const arr  = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  const r    = await mammoth.convertToHtml({ arrayBuffer: arr.buffer });
  const w    = document.createElement('div');
  w.className = 'fv-docx-wrap';
  w.innerHTML = r.value;
  document.getElementById('fv-body').innerHTML = '';
  document.getElementById('fv-body').appendChild(w);
}
