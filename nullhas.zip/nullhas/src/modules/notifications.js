// ── NOTIFICATIONS CENTER ──────────────────────────────────────────────────────
import { esc } from '../utils/helpers.js';
import { uid, fmtTimeAgo } from '../utils/helpers.js';

let NOTIFS = [];

export function loadNotifs() {
  try { const n = localStorage.getItem('sv4_notifs'); if (n) NOTIFS = JSON.parse(n); } catch { NOTIFS = []; }
}

export function saveNotifs() {
  try { localStorage.setItem('sv4_notifs', JSON.stringify(NOTIFS)); } catch (e) {}
}

export function addNotif(title, desc, icon = '🔔') {
  const n = { id: uid(), title, desc, icon, time: new Date().toISOString(), read: false };
  NOTIFS.unshift(n);
  if (NOTIFS.length > 80) NOTIFS = NOTIFS.slice(0, 80);
  saveNotifs();
  renderNotifBadge();
  renderNotifList();
  _playNotifBeep();
}

export function renderNotifBadge() {
  const badge  = document.getElementById('notif-badge'); if (!badge) return;
  const unread = NOTIFS.filter(n => !n.read).length;
  if (unread > 0) { badge.style.display = 'flex'; badge.textContent = unread > 9 ? '9+' : unread; }
  else badge.style.display = 'none';
}

export function toggleNotifPanel() {
  const panel = document.getElementById('notif-panel'); if (!panel) return;
  const isOpen = panel.classList.contains('open');
  if (isOpen) panel.classList.remove('open');
  else { panel.classList.add('open'); renderNotifList(); }
}

export function closeNotifPanel() {
  document.getElementById('notif-panel')?.classList.remove('open');
}

export function markAllNotifsRead() {
  NOTIFS.forEach(n => n.read = true);
  saveNotifs(); renderNotifBadge(); renderNotifList();
  window.toast?.('All notifications marked as read');
}

export function markNotifRead(idx) {
  if (NOTIFS[idx]) { NOTIFS[idx].read = true; saveNotifs(); renderNotifBadge(); renderNotifList(); }
}

export function renderNotifList() {
  const list = document.getElementById('notif-list'); if (!list) return;
  if (!NOTIFS.length) {
    list.innerHTML = `<div class="notif-empty"><div class="notif-empty-icon">🔕</div><div>No notifications yet</div></div>`;
    return;
  }
  list.innerHTML = NOTIFS.map((n, i) => `
    <div class="notif-item ${n.read ? '' : 'unread'}" onclick="window._markNotifRead(${i})">
      <div class="notif-item-header">
        <div class="notif-item-icon">${n.icon}</div>
        <div class="notif-item-title">${esc(n.title)}</div>
      </div>
      ${n.desc ? `<div class="notif-item-desc">${esc(n.desc)}</div>` : ''}
      <div class="notif-item-time">${fmtTimeAgo(n.time)}</div>
    </div>`).join('');
}

function _playNotifBeep() {
  try {
    const ctx  = new (window.AudioContext || window.webkitAudioContext)();
    const count = 5, dur = 0.12, gap = 0.09;
    for (let i = 0; i < count; i++) {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type = 'sine';
      const t = ctx.currentTime + (i * (dur + gap));
      o.frequency.setValueAtTime(880, t);
      o.frequency.exponentialRampToValueAtTime(660, t + dur);
      g.gain.setValueAtTime(0.18, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.start(t); o.stop(t + dur);
      if (i === count - 1) o.onended = () => ctx.close();
    }
  } catch (e) {}
}

window._markNotifRead = markNotifRead;
