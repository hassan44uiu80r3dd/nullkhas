// ── CALENDAR MODULE ───────────────────────────────────────────────────────────
import { D, calMonth, calYear, calSelected, setCalMonth, setCalYear, setCalSelected } from '../data/store.js';
import { esc, fmtDate, daysUntil, DAYS } from '../utils/helpers.js';

export function renderCalendar() {
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('cal-month-lbl').textContent = months[calMonth] + ' ' + calYear;
  const grid = document.getElementById('cal-grid');
  grid.innerHTML = '';

  DAYS.forEach(d => {
    const h = document.createElement('div');
    h.className = 'cal-day-hdr'; h.textContent = d; grid.appendChild(h);
  });

  const first    = new Date(calYear, calMonth, 1).getDay();
  const days     = new Date(calYear, calMonth + 1, 0).getDate();
  const prevDays = new Date(calYear, calMonth, 0).getDate();
  const today    = new Date();
  const events   = getAllCalEvents();

  for (let i = 0; i < 42; i++) {
    const cell = document.createElement('div');
    cell.className = 'cal-day';
    let dayNum, isOther = false;
    if (i < first)          { dayNum = prevDays - (first - 1 - i); isOther = true; }
    else if (i >= first + days) { dayNum = i - first - days + 1; isOther = true; }
    else dayNum = i - first + 1;

    if (isOther) cell.classList.add('other-month');
    const thisDate = isOther ? null : new Date(calYear, calMonth, dayNum);
    if (thisDate && thisDate.toDateString() === today.toDateString()) cell.classList.add('today');

    cell.innerHTML = `<div class="cal-day-num">${dayNum}</div><div class="cal-dots"></div>`;

    if (thisDate) {
      const dateStr  = `${calYear}-${String(calMonth + 1).padStart(2,'0')}-${String(dayNum).padStart(2,'0')}`;
      const dayEvts  = events.filter(e => e.date === dateStr);
      if (dayEvts.length) {
        const dots = cell.querySelector('.cal-dots');
        dayEvts.slice(0, 3).forEach(ev => {
          const dot = document.createElement('div');
          dot.className = 'cal-dot'; dot.style.background = ev.color; dots.appendChild(dot);
        });
      }
      cell.onclick = () => { setCalSelected(dateStr); renderCalEvents(dateStr); };
    }
    grid.appendChild(cell);
  }
  renderCalUpcoming(events);
}

export function getAllCalEvents() {
  const events = [];
  D.subjects.forEach(s => {
    const col     = `rgb(${s.cr},${s.cg},${s.cb})`;
    const doneCol = `rgba(${s.cr},${s.cg},${s.cb},0.35)`;
    s.assignments.forEach(a => {
      if (a.due) events.push({ date: a.due, title: a.title, sub: s.name, color: a.done ? doneCol : col, icon: s.icon, done: !!a.done });
    });
  });
  _getReminders().forEach(r => {
    events.push({ date: r.date, title: r.title, sub: r.desc || 'Reminder', color: '#a5afc8', icon: '🔔' });
  });
  return events;
}

export function renderCalEvents(dateStr) {
  const events = getAllCalEvents().filter(e => e.date === dateStr);
  const lbl    = document.getElementById('cal-selected-lbl');
  const list   = document.getElementById('cal-events-list');
  if (!events.length) { lbl.style.display = 'none'; list.innerHTML = ''; return; }
  lbl.style.display = 'block'; lbl.textContent = `Events on ${fmtDate(dateStr)}`;
  list.innerHTML = '';
  events.forEach(ev => {
    const d = document.createElement('div');
    d.className = 'cal-event-item';
    d.innerHTML = `<div class="cal-event-dot" style="background:${ev.color}"></div><div class="cal-event-title">${esc(ev.title)}</div><div class="cal-event-date">${esc(ev.sub)}</div>`;
    list.appendChild(d);
  });
}

export function renderCalUpcoming(events) {
  const list    = document.getElementById('cal-upcoming-list'); if (!list) return;
  list.innerHTML = '';
  const today   = new Date().toISOString().split('T')[0];
  const upcoming = (events || getAllCalEvents()).filter(e => e.date >= today && !e.done).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 8);
  if (!upcoming.length) { list.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,0.2);">No upcoming deadlines</div>'; return; }
  upcoming.forEach(ev => {
    const d      = daysUntil(ev.date);
    const dayStr = d === 0 ? '<span style="color:#f87171">Today</span>' : d === 1 ? '<span style="color:#facc15">Tomorrow</span>' : `${d}d`;
    const el     = document.createElement('div');
    el.className = 'cal-event-item';
    el.innerHTML = `<div class="cal-event-dot" style="background:${ev.color}"></div><div class="cal-event-title">${ev.icon || ''} ${esc(ev.title)}</div><div class="cal-event-date">${esc(ev.sub)} · ${dayStr}</div>`;
    list.appendChild(el);
  });
}

export function calPrev() { setCalMonth(calMonth - 1 < 0 ? 11 : calMonth - 1); if (calMonth === 11) setCalYear(calYear - 1); renderCalendar(); }
export function calNext() { setCalMonth(calMonth + 1 > 11 ? 0  : calMonth + 1); if (calMonth === 0)  setCalYear(calYear + 1); renderCalendar(); }

// ── REMINDERS ────────────────────────────────────────────────────────────────
let REMINDERS = [];

export function loadReminders() {
  try { const r = localStorage.getItem('sv4_reminders'); if (r) REMINDERS = JSON.parse(r); } catch { REMINDERS = []; }
}

export function saveReminders() {
  try { localStorage.setItem('sv4_reminders', JSON.stringify(REMINDERS)); } catch (e) {}
}

export function openReminderModal() {
  document.getElementById('rem-title').value = '';
  document.getElementById('rem-date').value  = '';
  document.getElementById('rem-time').value  = '';
  document.getElementById('rem-desc').value  = '';
  import('../ui/modals.js').then(m => { m.openModal('modal-reminder'); setTimeout(() => document.getElementById('rem-title').focus(), 200); });
}

export function saveReminder() {
  const title = document.getElementById('rem-title').value.trim();
  const date  = document.getElementById('rem-date').value;
  if (!title) { window.toast?.('Please enter a reminder title!'); return; }
  if (!date)  { window.toast?.('Please select a date!'); return; }
  const rem = { id: Date.now().toString(36) + Math.random().toString(36).slice(2), title, date, time: document.getElementById('rem-time').value || '', desc: document.getElementById('rem-desc').value.trim(), notified: false };
  REMINDERS.push(rem);
  saveReminders();
  import('../modules/notifications.js').then(m => m.addNotif('📅 Reminder set: ' + title, `Date: ${fmtDate(date)}${rem.time ? ' at ' + rem.time : ''}`, '📅'));
  import('../ui/modals.js').then(m => m.closeModal('modal-reminder'));
  renderCalReminders();
  import('./analytics.js').then(m => m.renderAnalytics());
  window.toast?.('Reminder saved! 🔔');
}

export function deleteReminder(id) {
  REMINDERS = REMINDERS.filter(r => r.id !== id);
  saveReminders(); renderCalReminders();
  import('./analytics.js').then(m => m.renderAnalytics());
  window.toast?.('Reminder removed');
}

export function renderCalReminders() {
  const list = document.getElementById('cal-rem-list'); if (!list) return;
  if (!REMINDERS.length) { list.innerHTML = '<div style="font-size:11px;color:rgba(255,255,255,0.2);padding:8px 0;">No reminders yet</div>'; return; }
  const sorted = [...REMINDERS].sort((a, b) => a.date.localeCompare(b.date));
  list.innerHTML = '';
  sorted.forEach(r => {
    const d    = daysUntil(r.date);
    const dayStr = d === 0 ? '🔴 TODAY' : d === 1 ? '🟡 Tomorrow' : d < 0 ? '✅ Past' : `📅 ${d}d away`;
    const el   = document.createElement('div');
    el.className = 'rem-item';
    el.innerHTML = `<div class="rem-item-icon">🔔</div><div class="rem-item-info"><div class="rem-item-title">${esc(r.title)}</div><div class="rem-item-sub">${fmtDate(r.date)}${r.time ? ' · ' + r.time : ''} · ${dayStr}</div>${r.desc ? `<div class="rem-item-sub" style="margin-top:2px;">${esc(r.desc)}</div>` : ''}</div><div class="rem-item-del" onclick="window._deleteReminder('${r.id}')"><svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg></div>`;
    list.appendChild(el);
  });
}

export function checkReminderNotifications() {
  const today = new Date().toISOString().split('T')[0];
  let changed = false;
  REMINDERS.forEach(r => {
    if (r.date === today && !r.notified) {
      r.notified = true; changed = true;
      import('../modules/notifications.js').then(m => m.addNotif('🔔 Reminder: ' + r.title, r.desc || `Scheduled for today${r.time ? ' at ' + r.time : ''}`, '🔔'));
      window.toast?.(`🔔 Reminder: ${r.title}`, 4000);
    }
  });
  if (changed) saveReminders();
}

export function scheduleReminderCheck() {
  checkReminderNotifications();
  // BUG FIX: use single `now` reference to avoid second-boundary mismatch
  const now = new Date();
  const msToNextMinute = (60 - now.getSeconds()) * 1000 - now.getMilliseconds();
  setTimeout(() => {
    checkReminderNotifications();
    setInterval(checkReminderNotifications, 60000);
  }, msToNextMinute);
}

export function getReminders() { return REMINDERS; }

function _getReminders() { return REMINDERS; }

window._deleteReminder = deleteReminder;
