// ── DEFAULTS ──────────────────────────────────────────────────────────────────
import { uid } from '../utils/helpers.js';

export const EMOJIS = [
  '📖','✏️','🔬','📐','💻','⌨️','🧮','📊','🔭','🧪',
  '📝','🎨','🌐','📡','🧠','📜','🏛️','⚗️','☪️','🎯',
  '🔢','🎭','🖥️','📚','🔑','💡','🧲','🔐','📋','🏆',
];

export const COLS = [
  { r:129,  g:140,  b:248,  hex:'#818cf8' },
  { r:192,  g:132,  b:252,  hex:'#c084fc' },
  { r:45,   g:212,  b:191,  hex:'#2dd4bf' },
  { r:251,  g:113,  b:133,  hex:'#fb7185' },
  { r:251,  g:191,  b:36,   hex:'#fbbf24' },
  { r:74,   g:222,  b:128,  hex:'#4ade80' },
  { r:34,   g:211,  b:238,  hex:'#22d3ee' },
  { r:248,  g:113,  b:113,  hex:'#f87171' },
  { r:250,  g:204,  b:21,   hex:'#facc15' },
  { r:96,   g:165,  b:250,  hex:'#60a5fa' },
  { r:165,  g:175,  b:210,  hex:'#a5afd2' },
  { r:240,  g:240,  b:240,  hex:'#f0f0f0' },
];

/**
 * Generate default subjects for new users
 * @returns {Array}
 */
export function getDefaultSubjects() {
  const defaults = [
    { name:'Calculus',                 code:'CALC',    icon:EMOJIS[0],  cr:165, cg:175, cb:210 },
    { name:'Applied Physics',          code:'PHY',     icon:EMOJIS[8],  cr:90,  cg:140, cb:220 },
    { name:'Functional English',       code:'ENG',     icon:EMOJIS[1],  cr:74,  cg:222, cb:128 },
    { name:'Programming Fundamentals', code:'PF',      icon:EMOJIS[5],  cr:250, cg:204, cb:21  },
    { name:'Programming Lab',          code:'PF-LAB',  icon:EMOJIS[22], cr:251, cg:146, cb:60  },
    { name:'ICT',                      code:'ICT',     icon:EMOJIS[12], cr:34,  cg:211, cb:238 },
    { name:'Pre-Calculus',             code:'PRE-CALC',icon:EMOJIS[3],  cr:192, cg:132, cb:252 },
    { name:'Holy Quran',               code:'QRN',     icon:EMOJIS[18], cr:251, cg:146, cb:60  },
  ];

  return defaults.map(s => ({
    id: uid(),
    name: s.name,
    code: s.code,
    icon: s.icon,
    cr: s.cr, cg: s.cg, cb: s.cb,
    notes: [],
    assignments: [],
    quizzes: [],
    syllabus: { text: '', topics: [] }
  }));
}
