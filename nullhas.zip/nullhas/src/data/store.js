// ── CENTRAL STATE STORE ───────────────────────────────────────────────────────

/**
 * Main data object — single source of truth
 * @type {{
 *   subjects: Array,
 *   studyLog: Array,
 *   settings: { name: string, pinEnabled: boolean, pin: string, major: string, semester: string }
 * }}
 */
export const D = {
  subjects: [],
  studyLog: [],
  settings: {
    name: '',
    pinEnabled: false,
    pin: '',
    major: '',
    semester: ''
  }
};

/** Currently open subject ID */
export let CID = null;
export function setCID(id) { CID = id; }
export function getCID() { return CID; }

/** Note filter state */
export let noteFilter = 'all';
export function setNoteFilter(f) { noteFilter = f; }

/** Assignment filter state */
export let asgnFilter = 'all';
export function setAsgnFilter(f) { asgnFilter = f; }

/** UI state */
export let fabOpen = false;
export function setFabOpen(v) { fabOpen = v; }

/** Subject modal selection state */
export let selEm = '📖';
export let selCol = { r: 129, g: 140, b: 248, hex: '#818cf8' };
export function setSelEm(v) { selEm = v; }
export function setSelCol(v) { selCol = v; }

/** Edit subject selection state */
export let editSubSelEm = '📖';
export let editSubSelCol = { r: 129, g: 140, b: 248, hex: '#818cf8' };
export function setEditSubSelEm(v) { editSubSelEm = v; }
export function setEditSubSelCol(v) { editSubSelCol = v; }

/** Timer state */
export let timerRunning = false;
export let timerElapsed = 0;
export let timerStart_ = 0;
export let timerInterval = null;
export let timerSubjectId = null;
export let pomoDone = 0;

export function setTimerRunning(v) { timerRunning = v; }
export function setTimerElapsed(v) { timerElapsed = v; }
export function setTimerStart(v) { timerStart_ = v; }
export function setTimerInterval(v) { timerInterval = v; }
export function setTimerSubjectId(v) { timerSubjectId = v; }
export function setPomoDone(v) { pomoDone = v; }

/** Calendar state */
const now = new Date();
export let calMonth = now.getMonth();
export let calYear  = now.getFullYear();
export let calSelected = null;
export function setCalMonth(v) { calMonth = v; }
export function setCalYear(v)  { calYear  = v; }
export function setCalSelected(v) { calSelected = v; }

/** Quiz edit state */
export let editQuizId = null;
export function setEditQuizId(v) { editQuizId = v; }

/** Note read state */
export let currentNoteId_read = null;
export function setCurrentNoteId_read(v) { currentNoteId_read = v; }

/** PDF viewer state */
export let pdfDoc = null, pdfPg = 1, pdfTot = 1;
export function setPdfDoc(v) { pdfDoc = v; }
export function setPdfPg(v)  { pdfPg  = v; }
export function setPdfTot(v) { pdfTot = v; }

/** Auto-save timer for notes */
export let autoSaveTimer = null;
export function setAutoSaveTimer(v) { autoSaveTimer = v; }

/**
 * Get currently open subject object
 * @returns {object|undefined}
 */
export function getSub() {
  return D.subjects.find(x => x.id === CID);
}
