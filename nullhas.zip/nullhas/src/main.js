// ── NULLHAS — MAIN ENTRY POINT ────────────────────────────────────────────────
import './ui/toast.js';  // register window.toast first

import { StorageEngine }           from './storage/StorageEngine.js';
import { openDB }                  from './storage/idb.js';
import { load }                    from './storage/persist.js';
import { loadSemDates }            from './utils/phase.js';
import { loadTheme, toggleTheme, setThemeMode, loadAccentTheme, setAccentTheme } from './ui/theme.js';
import { initIcons }               from './ui/icons.js';
import { showView, goBack }        from './ui/views.js';
import { openModal, closeModal, confirmDelete, confirmAction, showUndo, doUndo, initModalListeners } from './ui/modals.js';
import { renderSettingsPage, saveSemesterDates, saveSettings, updateStorageBar, checkLock, pinKey, togglePinLock, setPinPress, setPinBackspace, resetPinFromLock, exportData, importData, clearAllData } from './ui/settings.js';
import { loadNotifs, renderNotifBadge, toggleNotifPanel, closeNotifPanel, markAllNotifsRead } from './modules/notifications.js';
import { loadReminders, scheduleReminderCheck, openReminderModal, saveReminder, deleteReminder, renderCalReminders } from './modules/calendar.js';
import { OnboardingSystem }        from './modules/onboarding.js';
import { toggleFab, closeFab, fabAddSubject, fabAddNote, fabAddAsgn } from './modules/fab.js';
import { toggleSearch, doSearch }  from './modules/search.js';
import { openAddSubject, saveSubject, openEditSubject, saveEditSubject } from './modules/subjects.js';
import { openNoteModal, saveNote, confirmCloseNote, handleTagInput, scheduleAutoSave, toggleReadNoteStar, printNote, exportCurrentNoteDOCX, exportCurrentNotePDF, setNotePriority } from './modules/notes.js';
import { openAsgnModal, saveAsgn, addSubtaskInput, onFileSelect } from './modules/assignments.js';
import { openQuizModal, saveQuiz }  from './modules/quiz.js';
import { openTopicModal, saveTopic, saveSyllabus } from './modules/syllabus.js';
import { pdfPrev, pdfNext }        from './modules/fileViewer.js';
import { timerStart, timerPause, timerStop, setTimerSubject, clearStudyLog, restoreTimerState, populateTimerSelect } from './modules/timer.js';
import { calPrev, calNext }        from './modules/calendar.js';
import { execFmt, insertCodeBlock, insertImageFile, updateRteState, rteChange, rteDragOver, rteDragLeave, rteDrop, rtePaste } from './ui/rte.js';

// ── EXPOSE ALL FUNCTIONS TO HTML onclick HANDLERS ────────────────────────────
Object.assign(window, {
  // Navigation
  showView, goBack,
  // Modals
  openModal, closeModal, confirmDelete, doUndo,
  // Theme
  toggleTheme, setThemeMode, setAccentTheme,
  // FAB
  toggleFab, fabAddSubject, fabAddNote, fabAddAsgn,
  quickNote: () => import('./modules/fab.js').then(m => m.fabAddNote()),
  quickAsgn: () => import('./modules/fab.js').then(m => m.fabAddAsgn()),
  quickQuiz: () => import('./modules/fab.js').then(m => m.fabAddQuiz()),
  quickReminder: () => import('./modules/calendar.js').then(m => m.openReminderModal()),
  // Search
  toggleSearch, doSearch,
  // Notifications
  toggleNotifPanel, closeNotifPanel, markAllNotifsRead,
  // Subjects
  openAddSubject, saveSubject, openEditSubject, saveEditSubject,
  // Notes
  openNoteModal, saveNote, confirmCloseNote, handleTagInput, scheduleAutoSave, toggleReadNoteStar, printNote, exportCurrentNoteDOCX, exportCurrentNotePDF, setNotePriority,
  tagKeydown: handleTagInput,
  // RTE
  execFmt, insertCodeBlock, insertImageFile, updateRteState, rteChange, rteDragOver, rteDragLeave, rteDrop, rtePaste,
  // Assignments
  openAsgnModal, saveAsgn, addSubtaskInput, onFileSelect,
  // Quiz
  openQuizModal, saveQuiz,
  // Syllabus
  openTopicModal, saveTopic, saveSyllabus,
  // File viewer
  pdfPrev, pdfNext,
  // Timer
  timerStart, timerPause, timerStop, setTimerSubject, clearStudyLog,
  // Calendar
  calPrev, calNext, openReminderModal, saveReminder, deleteReminder,
  // Settings
  renderSettingsPage, saveSemesterDates, saveSettings, exportData, importData, clearAllData,
  pinKey, togglePinLock, setPinPress, setPinBackspace, resetPinFromLock,
  // Storage — expose for HTML onclick + wrappers with confirmDelete
  StorageEngine,
  switchToStorage: (b) => StorageEngine.switchTo(b, (msg, sub, cb) => confirmAction(msg, sub, cb, 'Switch')),
  executeStorageMigration: () => StorageEngine._executePendingMigration(),
});

// ── ASYNC BOOT SEQUENCE ───────────────────────────────────────────────────────
(async () => {
  // 1. Init storage backend
  await StorageEngine.init();

  // 2. Open IDB file store
  try { await openDB(); } catch (e) {}

  // 3. Load all app data
  await load();

  // 4. Load preferences (non-async)
  loadSemDates();
  loadNotifs();
  loadReminders();
  loadTheme();
  loadAccentTheme();

  // 5. Init UI
  checkLock();
  initIcons();
  initModalListeners(confirmCloseNote);

  // 6. Show initial view
  showView('analytics');

  // 7. Update storage bar
  await updateStorageBar();

  // 8. Restore timer state
  setTimeout(() => { populateTimerSelect(); restoreTimerState(); }, 200);

  // 9. Start reminder scheduler (aligned to minute boundary)
  scheduleReminderCheck();

  // 10. Run onboarding AFTER everything is ready (BUG FIX: no arbitrary delay)
  OnboardingSystem.init();

  renderNotifBadge();
})();

// ── GLOBAL CLICK HANDLER (FAB + Notif panel outside click) ───────────────────
document.addEventListener('click', e => {
  const fab = document.getElementById('fab');
  if (fab && !e.target.closest('.fab') && !e.target.closest('.fab-menu')) closeFab();
  const panel = document.getElementById('notif-panel');
  if (panel?.classList.contains('open') && !e.target.closest('.notif-panel') && !e.target.closest('.notif-btn-wrap')) closeNotifPanel();
});

// ── STORAGE CARDS: keyboard accessibility ────────────────────────────────────
document.addEventListener('keydown', e => {
  const card = e.target.closest('.storage-loc-card[role="button"]');
  if (card && (e.key === 'Enter' || e.key === ' ')) {
    e.preventDefault();
    const id = card.id;
    const backend = id?.replace('sloc-', '');
    if (backend && window.switchToStorage) window.switchToStorage(backend);
  }
});

// ── FAB: keyboard accessibility ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const fab = document.getElementById('fab');
  if (fab) {
    fab.setAttribute('role', 'button');
    fab.setAttribute('aria-label', 'Open quick actions');
    fab.setAttribute('aria-expanded', 'false');
    fab.setAttribute('tabindex', '0');
    fab.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggleFab();
      }
    });
  }
});
