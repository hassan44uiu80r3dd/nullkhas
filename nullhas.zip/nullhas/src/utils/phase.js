// ── SEMESTER PHASE ENGINE ─────────────────────────────────────────────────────
import { daysUntil } from './helpers.js';

/** @type {{ start: string, mid: string, final: string }} */
export let SD = { start: '', mid: '', final: '' };

const SEM_KEY = 'sv4_sem';

export function loadSemDates() {
  try {
    const s = localStorage.getItem(SEM_KEY);
    if (s) {
      const p = JSON.parse(s);
      SD.start = p.start || '';
      SD.mid   = p.mid   || '';
      SD.final = p.final || '';
    }
  } catch (e) {}
}

export function saveSemDates(start, mid, final) {
  SD.start = start || '';
  SD.mid   = mid   || '';
  SD.final = final || '';
  try { localStorage.setItem(SEM_KEY, JSON.stringify(SD)); } catch (e) {}
}

/**
 * Detect current semester phase
 * @returns {'pre-mid'|'post-mid'|'final'|'none'}
 */
export function detectPhase() {
  if (!SD.mid || !SD.final) return 'none';
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const start = SD.start ? new Date(SD.start + 'T00:00:00') : null;
  const mid   = new Date(SD.mid   + 'T00:00:00');
  const fin   = new Date(SD.final + 'T00:00:00');
  if (start && today < start) return 'none';
  if (today < mid) return 'pre-mid';
  if (today >= mid && today < fin) return 'post-mid';
  if (today >= fin) return 'final';
  return 'none';
}

/**
 * Get display info for a phase
 * @param {'pre-mid'|'post-mid'|'final'|'none'} ph
 */
export function getPhaseLabel(ph) {
  const map = {
    'pre-mid':  { emoji: '🟢', text: 'Pre-Mid Phase Active',        cls: 'pre-mid',  sub: 'Focus on assignments and quizzes' },
    'post-mid': { emoji: '🟠', text: 'Post-Mid Phase Active',       cls: 'post-mid', sub: 'Projects & presentations now relevant' },
    'final':    { emoji: '🔴', text: 'Final Phase / Semester End',  cls: 'final',    sub: 'Major focus: Final Exam preparation' },
    'none':     { emoji: '⚙️', text: 'Semester Phase Unknown',      cls: 'no-config',sub: 'Configure semester dates in Settings' },
  };
  return map[ph] || map['none'];
}

/**
 * Build phase notification items for current deadlines
 * @param {Array} subjects
 * @returns {Array}
 */
export function getPhaseNotifications(subjects) {
  const items = [];
  const ph = detectPhase();

  if (SD.mid && (ph === 'pre-mid' || ph === 'post-mid')) {
    const d = daysUntil(SD.mid);
    if (d !== null && d >= 0 && d <= 7) {
      items.push({
        urgent: d <= 2, icon: '📋',
        title: 'Mid Exam approaching',
        sub: `${SD.mid} — ${d === 0 ? 'TODAY' : d + 'd left'}`,
        badge: d <= 2 ? 'urgent' : 'soon'
      });
    }
  }

  if (SD.final && (ph === 'post-mid' || ph === 'final')) {
    const d = daysUntil(SD.final);
    if (d !== null && d >= 0 && d <= 7) {
      items.push({
        urgent: d <= 2, icon: '🎓',
        title: 'Final Exam approaching',
        sub: `${SD.final} — ${d === 0 ? 'TODAY' : d + 'd left'}`,
        badge: d <= 2 ? 'urgent' : 'soon'
      });
    }
  }

  subjects.forEach(s => {
    s.assignments.forEach(a => {
      if (a.done) return;
      const d = daysUntil(a.due);
      if (d !== null && d >= 0 && d <= 7) {
        items.push({
          urgent: d <= 1, icon: '✅',
          title: a.title + ' due',
          sub: `${s.name} — ${d === 0 ? 'TODAY' : d === 1 ? 'Tomorrow' : d + 'd left'}`,
          badge: d <= 1 ? 'urgent' : 'soon'
        });
      }
    });
  });

  return items.slice(0, 5);
}
