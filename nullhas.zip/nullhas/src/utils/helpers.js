// ── HELPERS ──────────────────────────────────────────────────────────────────

/**
 * Generate a unique ID
 * @returns {string}
 */
export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/**
 * Escape HTML to prevent XSS
 * @param {string} s
 * @returns {string}
 */
export function esc(s) {
  const d = document.createElement('div');
  d.textContent = String(s || '');
  return d.innerHTML;
}

/**
 * Format a date string (YYYY-MM-DD) to human-readable
 * @param {string} d
 * @returns {string}
 */
export function fmtDate(d) {
  if (!d) return '';
  try {
    return new Date(d + 'T00:00:00').toLocaleDateString('en-PK', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return '';
  }
}

/**
 * Format seconds into human-readable duration
 * @param {number} sec
 * @returns {string}
 */
export function fmtDur(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h ? `${h}h ${m}m` : `${m}m ${s}s`;
}

/**
 * Calculate days until a date string (YYYY-MM-DD)
 * Returns null if invalid, negative if overdue
 * @param {string} dStr
 * @returns {number|null}
 */
export function daysUntil(dStr) {
  if (!dStr) return null;
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dStr + 'T00:00:00');
    if (isNaN(due.getTime())) return null;
    return Math.round((due - today) / 864e5);
  } catch (e) {
    return null;
  }
}

/**
 * Format ISO timestamp to "time ago" string
 * @param {string} iso
 * @returns {string}
 */
export function fmtTimeAgo(iso) {
  if (!iso) return '';
  const diff = Math.floor((Date.now() - new Date(iso)) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  if (diff < 86400 * 7) return Math.floor(diff / 86400) + 'd ago';
  return new Date(iso).toLocaleDateString('en-PK', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

/**
 * Debounce a function
 * @param {Function} fn
 * @param {number} delay
 * @returns {Function}
 */
export function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

/**
 * Strip SVG/HTML tags from icon string — return plain emoji
 * @param {string} icon
 * @returns {string}
 */
export function safeIcon(icon) {
  return String(icon || '📖').replace(/<[^>]+>/g, '').trim() || '📖';
}

export const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
