// ── MODALS & UNDO ─────────────────────────────────────────────────────────────
import { ICONS } from './icons.js';
import { esc } from '../utils/helpers.js';
import { autoSaveTimer, setAutoSaveTimer } from '../data/store.js';

export function openModal(id) {
  document.getElementById(id)?.classList.add('open');
}

export function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
  if (id === 'modal-note') {
    clearTimeout(autoSaveTimer);
    setAutoSaveTimer(null);
  }
}

export function closeAllModals() {
  document.querySelectorAll('.overlay.open').forEach(o => o.classList.remove('open'));
}

/**
 * Show a confirmation dialog
 * @param {string} msg - Title
 * @param {string} sub - Subtitle
 * @param {Function} cb - Callback on confirm
 * @param {Object} [opts] - Options: { confirmLabel, danger }
 */
export function confirmDelete(msg, sub, cb, opts = {}) {
  const { confirmLabel = 'Delete', danger = true } = opts;
  document.getElementById('cfm-msg').textContent = msg;
  document.getElementById('cfm-sub').textContent = sub;

  const oldBtn = document.getElementById('cfm-yes');
  const newBtn = oldBtn.cloneNode(true);
  newBtn.textContent = confirmLabel;
  newBtn.classList.toggle('danger', danger);
  newBtn.classList.toggle('primary', !danger);
  oldBtn.parentNode.replaceChild(newBtn, oldBtn);
  newBtn.addEventListener('click', () => {
    closeModal('modal-confirm');
    cb?.();
  }, { once: true });

  openModal('modal-confirm');
}

/** Alias for non-destructive confirm (e.g. storage switch) */
export function confirmAction(msg, sub, cb, confirmLabel = 'Confirm') {
  return confirmDelete(msg, sub, cb, { confirmLabel, danger: false });
}

// ── UNDO TOAST ───────────────────────────────────────────────────────────────
let _undoTimer = null;
let _undoCb    = null;

export function showUndo(label, cb) {
  _undoCb = cb;
  clearTimeout(_undoTimer);

  const bar = document.getElementById('undo-bar');
  const msg = document.getElementById('undo-msg');
  if (!bar || !msg) return;

  msg.textContent = label;
  bar.classList.add('show');

  _undoTimer = setTimeout(() => {
    bar.classList.remove('show');
    _undoCb = null;
  }, 5000);
}

export function doUndo() {
  clearTimeout(_undoTimer);
  const bar = document.getElementById('undo-bar');
  bar?.classList.remove('show');
  _undoCb?.();
  _undoCb = null;
}

// ── BACKDROP CLICK & KEYBOARD SHORTCUTS ─────────────────────────────────────
export function initModalListeners(confirmCloseNoteFn) {
  document.querySelectorAll('.overlay').forEach(o => {
    o.addEventListener('click', function (e) {
      if (e.target !== this) return;
      if (this.id === 'modal-note') { confirmCloseNoteFn(); return; }
      closeModal(this.id);
    });
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      const noteModal = document.getElementById('modal-note');
      if (noteModal?.classList.contains('open')) { confirmCloseNoteFn(); return; }
      closeAllModals();
      // close search
      const sp = document.getElementById('search-panel');
      if (sp?.style.display !== 'none') sp.style.display = 'none';
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      import('../modules/search.js').then(m => m.toggleSearch());
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      const noteModal = document.getElementById('modal-note');
      if (noteModal?.classList.contains('open')) {
        e.preventDefault();
        import('../modules/notes.js').then(m => m.saveNote());
      }
    }
  });
}
