// ── VIEW NAVIGATION ───────────────────────────────────────────────────────────
import { closeNotifPanel } from '../modules/notifications.js';
import { closeFab } from '../modules/fab.js';

/** Prefetch likely next views when idle */
function _prefetchViews() {
  if ('requestIdleCallback' in window) {
    requestIdleCallback(() => {
      import('../modules/subjects.js');
      import('../modules/calendar.js');
      import('../modules/timer.js');
    }, { timeout: 2000 });
  }
}

export function showView(v) {
  document.querySelectorAll('.view').forEach(x => x.classList.remove('active'));
  document.getElementById('view-' + v)?.classList.add('active');

  document.querySelectorAll('.tbtn[id^="btn-"]').forEach(b => b.classList.remove('on'));
  document.getElementById('btn-' + v)?.classList.add('on');

  document.title = 'nullHas' + (v !== 'analytics' ? ' — ' + v.charAt(0).toUpperCase() + v.slice(1) : '');

  // Lazy-load each view's render function
  const renders = {
    analytics: () => import('../modules/analytics.js').then(m => { m.renderAnalytics(); import('../modules/assignments.js').then(a => a.renderDueAlerts()); }),
    subjects:  () => import('../modules/subjects.js').then(m => m.renderDash()),
    calendar:  () => import('../modules/calendar.js').then(m => { m.renderCalendar(); m.renderCalReminders(); }),
    timer:     () => import('../modules/timer.js').then(m => { m.renderTimer(); m.populateTimerSelect(); }),
    settings:  () => import('./settings.js').then(m => m.renderSettingsPage()),
  };

  renders[v]?.();
  _prefetchViews();
  closeFab();
  closeNotifPanel();
  // Hide subject-specific FAB items when leaving detail view
  const fn = document.getElementById('fab-note');
  const fa = document.getElementById('fab-asgn');
  const fq = document.getElementById('fab-quiz');
  if (fn) fn.style.display = 'none';
  if (fa) fa.style.display = 'none';
  if (fq) fq.style.display = 'none';
}

export function goBack() {
  showView('subjects');
}
