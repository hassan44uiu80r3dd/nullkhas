// ── THEME SYSTEM ──────────────────────────────────────────────────────────────
import { toast } from './toast.js';

let IS_DARK = true;

const THEME_COLOR_DARK = '#03030a';
const THEME_COLOR_LIGHT = '#dde1ef';

export const ACCENT_THEMES = {
  indigo: { r:129, g:140, b:248, hex:'#818cf8' },
  violet: { r:192, g:132, b:252, hex:'#c084fc' },
  teal:   { r:45,  g:212, b:191, hex:'#2dd4bf' },
  rose:   { r:251, g:113, b:133, hex:'#fb7185' },
  amber:  { r:251, g:191, b:36,  hex:'#fbbf24' },
  mono:   { r:240, g:240, b:240, hex:'#f0f0f0' },
};

let CURRENT_ACCENT = 'indigo';

function updateMetaThemeColor() {
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', IS_DARK ? THEME_COLOR_DARK : THEME_COLOR_LIGHT);
}

export function loadTheme() {
  try { const t = localStorage.getItem('sv4_theme'); IS_DARK = t !== 'light'; } catch (e) {}
  applyTheme();
}

export function applyTheme() {
  document.body.classList.toggle('light-mode', !IS_DARK);
  const moon  = document.getElementById('theme-icon-moon');
  const sun   = document.getElementById('theme-icon-sun');
  const moonS = document.getElementById('theme-icon-moon-s');
  const sunS  = document.getElementById('theme-icon-sun-s');
  if (moon)  moon.style.display  = IS_DARK ? 'block' : 'none';
  if (sun)   sun.style.display   = IS_DARK ? 'none'  : 'block';
  if (moonS) moonS.style.display = IS_DARK ? 'block' : 'none';
  if (sunS)  sunS.style.display  = IS_DARK ? 'none'  : 'block';
  updateMetaThemeColor();
  _updateModePillUI();
}

/** Set dark (true) or light (false) mode directly. Use from Settings pills. */
export function setThemeMode(dark) {
  if (IS_DARK === dark) return;
  IS_DARK = dark;
  applyTheme();
  try { localStorage.setItem('sv4_theme', IS_DARK ? 'dark' : 'light'); } catch (e) {}
  toast(IS_DARK ? 'Dark mode' : 'Light mode');
}

export function toggleTheme() {
  IS_DARK = !IS_DARK;
  applyTheme();
  try { localStorage.setItem('sv4_theme', IS_DARK ? 'dark' : 'light'); } catch (e) {}
  toast(IS_DARK ? 'Dark mode' : 'Light mode');
}

export function loadAccentTheme() {
  try { const t = localStorage.getItem('sv_accent'); if (t && ACCENT_THEMES[t]) CURRENT_ACCENT = t; } catch (e) {}
  applyAccentTheme(CURRENT_ACCENT, false);
}

export function applyAccentTheme(name, save = true) {
  const t = ACCENT_THEMES[name];
  if (!t) return;
  document.body.setAttribute('data-theme', name);
  const root = document.documentElement.style;
  root.setProperty('--accent-r', t.r);
  root.setProperty('--accent-g', t.g);
  root.setProperty('--accent-b', t.b);
  root.setProperty('--accent-hex', t.hex);

  if (name === 'mono') {
    root.setProperty('--bg-base',    '#000000');
    root.setProperty('--bg-surface', '#0a0a0a');
    root.setProperty('--bg-raised',  '#111111');
    root.setProperty('--bg-float',   '#1a1a1a');
  } else {
    ['--bg-base','--bg-surface','--bg-raised','--bg-float'].forEach(v => root.removeProperty(v));
  }

  CURRENT_ACCENT = name;

  // Update swatch / grid UIs
  document.querySelectorAll('.theme-swatch').forEach(s => s.classList.remove('active'));
  document.getElementById('theme-swatch-' + name)?.classList.add('active');
  document.querySelectorAll('.gcolor-item').forEach(el => el.classList.remove('active'));
  document.getElementById('gcolor-' + name)?.classList.add('active');

  const pb = document.getElementById('gcolor-preview');
  if (pb) pb.textContent = '✓ ' + name.charAt(0).toUpperCase() + name.slice(1) + ' theme active';

  _updateModePillUI();

  if (save) {
    try { localStorage.setItem('sv_accent', name); } catch (e) {}
    toast('🎨 ' + name.charAt(0).toUpperCase() + name.slice(1) + ' theme applied');
  }
}

export function setAccentTheme(name) { applyAccentTheme(name, true); }

function _updateModePillUI() {
  document.getElementById('mode-dark-opt')?.classList.toggle('active', IS_DARK);
  document.getElementById('mode-light-opt')?.classList.toggle('active', !IS_DARK);
}
