// ── SETTINGS PAGE ─────────────────────────────────────────────────────────────
import { D } from '../data/store.js';
import { persist } from '../storage/persist.js';
import { StorageEngine } from '../storage/StorageEngine.js';
import { SD, saveSemDates, detectPhase, getPhaseLabel } from '../utils/phase.js';
import { toast } from './toast.js';
import { confirmDelete } from './modals.js';

export function renderSettingsPage() {
  _renderSemDates();
  _renderProfileSection();
  _renderPinToggle();
  StorageEngine._updateUI();
  updateStorageBar();
}

function _renderProfileSection() {
  const nameEl = document.getElementById('s-name');
  if (nameEl) nameEl.value = D.settings.name || '';
}

function _renderPinToggle() {
  const toggle = document.getElementById('pin-toggle');
  const area = document.getElementById('pin-setup-area');
  if (toggle) toggle.classList.toggle('on', !!D.settings.pinEnabled);
  if (area) area.style.display = 'none';
}

function _renderSemDates() {
  const ss = document.getElementById('sem-start');
  const sm = document.getElementById('sem-mid');
  const sf = document.getElementById('sem-final');
  if (ss) ss.value = SD.start || '';
  if (sm) sm.value = SD.mid   || '';
  if (sf) sf.value = SD.final || '';
  updateSemPhasePreview();
}

export function saveSemesterDates() {
  const start = document.getElementById('sem-start')?.value || '';
  const mid   = document.getElementById('sem-mid')?.value   || '';
  const fin   = document.getElementById('sem-final')?.value || '';
  saveSemDates(start, mid, fin);
  updateSemPhasePreview();
  // Trigger phase banner re-render on home
  import('../modules/analytics.js').then(m => { m.renderPhaseBanner(); m.renderPhaseNotifications(); });
  toast('Semester dates saved! 📅');
}

export function saveSettings() {
  const nameEl = document.getElementById('s-name');
  if (nameEl) {
    D.settings.name = nameEl.value.trim();
    persist();
  }
}

export function updateSemPhasePreview() {
  const dot = document.getElementById('sem-phase-dot');
  const txt = document.getElementById('sem-phase-txt');
  if (!dot || !txt) return;
  const ph   = detectPhase();
  const info = getPhaseLabel(ph);
  const colMap = { 'pre-mid':'#4ade80', 'post-mid':'#facc15', 'final':'#f87171', 'none':'rgba(165,175,210,0.4)' };
  dot.style.background = colMap[ph] || colMap['none'];
  txt.textContent = ph === 'none' ? 'Configure dates above to enable phase detection' : 'Currently: ' + info.emoji + ' ' + info.text + ' Active';
}

export async function updateStorageBar() {
  try {
    const used  = await StorageEngine.getUsageBytes();
    const quota = await StorageEngine.getQuotaBytes();
    const pct   = quota > 0 ? Math.min(100, Math.round(used / quota * 100)) : 0;
    const kb    = used < 1024 * 1024
      ? (used / 1024).toFixed(1) + ' KB'
      : (used / (1024 * 1024)).toFixed(2) + ' MB';

    const fill = document.getElementById('storage-bar-fill');
    if (fill) {
      fill.style.width = pct + '%';
      fill.style.background = pct > 85
        ? 'linear-gradient(90deg,#f87171,#f43f5e)'
        : pct > 60
          ? 'linear-gradient(90deg,#facc15,#f59e0b)'
          : 'linear-gradient(90deg,var(--clr-success),var(--clr-warning))';
    }
    const t = document.getElementById('storage-used-kb');
    if (t) t.textContent = kb;
    const s = document.getElementById('storage-used-txt');
    if (s) {
      const qStr = quota >= 1024*1024*1024
        ? (quota/(1024*1024*1024)).toFixed(1)+' GB'
        : quota >= 1024*1024
          ? (quota/(1024*1024)).toFixed(0)+' MB'
          : (quota/1024).toFixed(0)+' KB';
      s.textContent = pct + '% used' + (quota > 5*1024*1024 ? ' of ' + qStr : '');
    }
    StorageEngine._updateUI();
  } catch (e) {}
}

// ── PIN LOCK ─────────────────────────────────────────────────────────────────
let _pinSetupVal = '';

export function checkLock() {
  if (!D.settings.pinEnabled || !D.settings.pin) return;
  const lock = document.getElementById('lock-screen');
  if (lock) lock.style.display = 'flex';
}

export function togglePinLock() {
  const toggle = document.getElementById('pin-toggle');
  const area = document.getElementById('pin-setup-area');
  if (!toggle || !area) return;
  const enabled = toggle.classList.contains('on');
  if (enabled) {
    D.settings.pinEnabled = false;
    D.settings.pin = '';
    toggle.classList.remove('on');
    area.style.display = 'none';
    toast('PIN lock disabled');
  } else {
    _pinSetupVal = '';
    _renderSetPinDots('');
    area.style.display = 'block';
    toggle.classList.add('on');
  }
  persist();
}

function _renderSetPinDots(val) {
  [0, 1, 2, 3].forEach(i => {
    const d = document.getElementById('sd' + i);
    if (d) d.classList.toggle('filled', i < val.length);
  });
}

export function setPinPress(k) {
  if (_pinSetupVal.length >= 4) return;
  _pinSetupVal += k;
  _renderSetPinDots(_pinSetupVal);
  if (_pinSetupVal.length >= 4) {
    D.settings.pin = _pinSetupVal;
    D.settings.pinEnabled = true;
    persist();
    document.getElementById('pin-setup-area').style.display = 'none';
    toast('PIN lock enabled');
  }
}

export function setPinBackspace() {
  _pinSetupVal = _pinSetupVal.slice(0, -1);
  _renderSetPinDots(_pinSetupVal);
}

export function resetPinFromLock() {
  confirmDelete('Reset PIN and delete all data?', 'This cannot be undone.', () => {
    D.settings.pinEnabled = false;
    D.settings.pin = '';
    D.subjects = [];
    D.studyLog = [];
    persist();
    document.getElementById('lock-screen').style.display = 'none';
    toast('Data reset. Please restart.');
    location.reload();
  });
}

export function pinKey(k) {
  const disp = document.getElementById('pin-display');
  if (!disp) return;
  const cur = disp.dataset.val || '';
  if (k === 'DEL') { disp.dataset.val = cur.slice(0,-1); }
  else if (cur.length < 6) { disp.dataset.val = cur + k; }
  _renderPinDots(disp.dataset.val);
  if (disp.dataset.val.length >= 4) _checkPin(disp.dataset.val);
}

function _renderPinDots(val) {
  const dots = document.querySelectorAll('#lock-dots .pin-dot');
  dots.forEach((d, i) => d.classList.toggle('filled', i < val.length));
}

function _checkPin(entered) {
  if (entered === D.settings.pin) {
    document.getElementById('lock-screen').style.display = 'none';
    document.getElementById('pin-display').dataset.val = '';
    _renderPinDots('');
  } else {
    const errEl = document.getElementById('lock-error');
    if (errEl) { errEl.textContent = 'Wrong PIN'; errEl.style.display = 'block'; }
    setTimeout(() => {
      document.getElementById('pin-display').dataset.val = '';
      _renderPinDots('');
      const e = document.getElementById('lock-error');
      if (e) { e.textContent = ''; e.style.display = 'none'; }
    }, 900);
  }
}

// ── DATA EXPORT / IMPORT ─────────────────────────────────────────────────────
export function exportData() {
  const json   = JSON.stringify(D, null, 2);
  const blob   = new Blob([json], { type:'application/json' });
  const url    = URL.createObjectURL(blob);
  const a      = document.createElement('a');
  a.href       = url;
  a.download   = 'nullhas_backup_' + new Date().toISOString().slice(0,10) + '.json';
  a.click();
  URL.revokeObjectURL(url);
  toast('📦 Data exported!');
}

export function importData(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const p = JSON.parse(e.target.result);
      if (!Array.isArray(p.subjects)) throw new Error('Invalid file format');
      confirmDelete(
        'Import data?',
        'This will replace all current data.',
        () => {
          D.subjects  = p.subjects  || [];
          D.studyLog  = p.studyLog  || [];
          D.settings  = Object.assign({ name:'', pinEnabled:false, pin:'', major:'', semester:'' }, p.settings || {});
          persist();
          toast('✅ Data imported successfully!');
          location.reload();
        }
      );
    } catch (err) {
      toast('❌ Import failed: ' + err.message);
    }
  };
  reader.readAsText(file);
}

export function clearAllData() {
  confirmDelete(
    'Clear ALL data?',
    'This will permanently delete all subjects, notes, assignments and quizzes.',
    () => {
      D.subjects = [];
      D.studyLog = [];
      persist();
      toast('All data cleared');
      location.reload();
    }
  );
}
