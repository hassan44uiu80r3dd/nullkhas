// ── RICH TEXT EDITOR (RTE) ───────────────────────────────────────────────────
// Handlers for contenteditable note body — formatting, paste, drag/drop

const RTE_BODY_ID = 'rte-body';

function getRteBody() {
  return document.getElementById(RTE_BODY_ID);
}

/**
 * Execute formatting command via document.execCommand
 */
export function execFmt(cmd, value = null) {
  const body = getRteBody();
  if (!body) return;
  body.focus();
  document.execCommand(cmd, false, value || null);
}

/**
 * Insert a code block (pre/code wrapper)
 */
export function insertCodeBlock() {
  const body = getRteBody();
  if (!body) return;
  body.focus();
  const sel = window.getSelection();
  const range = sel?.getRangeAt(0);
  if (!range) return;
  const pre = document.createElement('pre');
  pre.contentEditable = 'true';
  const code = document.createElement('code');
  code.textContent = '// code here';
  pre.appendChild(code);
  range.insertNode(pre);
  range.setStart(code, 0);
  range.setEnd(code, 0);
  sel?.removeAllRanges();
  sel?.addRange(range);
}

/**
 * Handle image file selection
 */
export function insertImageFile(inputEl) {
  if (!inputEl?.files?.length) return;
  const file = inputEl.files[0];
  if (!file.type.startsWith('image/')) return;
  const body = getRteBody();
  if (!body) return;
  const reader = new FileReader();
  reader.onload = () => {
    body.focus();
    document.execCommand('insertImage', false, reader.result);
  };
  reader.readAsDataURL(file);
  inputEl.value = '';
}

/**
 * Update word count and possibly toolbar state
 */
function updateWordCount() {
  const body = getRteBody();
  const el = document.getElementById('rte-word-count');
  if (!body || !el) return;
  const text = (body.innerText || '').replace(/\s+/g, ' ').trim();
  const words = text ? text.split(' ').length : 0;
  el.textContent = words + ' word' + (words !== 1 ? 's' : '');
}

/**
 * Update toolbar button states (bold, italic, etc.)
 */
export function updateRteState() {
  const body = getRteBody();
  if (!body) return;
  ['bold', 'italic', 'underline', 'strikeThrough'].forEach(cmd => {
    const btn = document.getElementById('rtb-' + cmd);
    if (btn) btn.classList.toggle('active', document.queryCommandState(cmd));
  });
  updateWordCount();
}

export function rteChange() {
  updateWordCount();
  import('../modules/notes.js').then(m => m.scheduleAutoSave?.());
}

export function rteDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'copy';
}

export function rteDragLeave(e) {
  e.preventDefault();
}

export function rteDrop(e) {
  e.preventDefault();
  const files = e.dataTransfer?.files;
  if (!files?.length) return;
  const img = Array.from(files).find(f => f.type.startsWith('image/'));
  if (!img) return;
  const reader = new FileReader();
  reader.onload = () => {
    const body = getRteBody();
    if (body) {
      body.focus();
      document.execCommand('insertImage', false, reader.result);
    }
  };
  reader.readAsDataURL(img);
}

export function rtePaste(e) {
  const items = e.clipboardData?.items;
  if (!items) return;
  const img = Array.from(items).find(i => i.type.startsWith('image/'));
  if (img) {
    e.preventDefault();
    const file = img.getAsFile();
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const body = getRteBody();
        if (body) document.execCommand('insertImage', false, reader.result);
      };
      reader.readAsDataURL(file);
    }
  }
}
