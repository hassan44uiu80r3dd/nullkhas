// ── STORAGE ENGINE ────────────────────────────────────────────────────────────

export const StorageEngine = {
  DATA_KEY:    'sv4_data',
  BACKEND_KEY: 'sv4_backend',
  backend:     'localstorage',

  _idbMain:     null,
  _memoryStore: {},
  _opfsReady:   false,
  _opfsRoot:    null,
  _pendingBackend: null,

  // ── INIT ────────────────────────────────────────────────────────────────────
  async init() {
    const saved = localStorage.getItem(this.BACKEND_KEY);
    if (saved && ['localstorage', 'idb', 'opfs', 'memory'].includes(saved)) {
      this.backend = saved;
    }
    if (this.backend === 'idb') await this._initIDB();
    if (this.backend === 'opfs') {
      try {
        await this._initOPFS();
      } catch (e) {
        console.warn('OPFS init failed:', e.message);
        this.backend = 'localstorage';
      }
    }
    this._updateUI();
  },

  async _initIDB() {
    return new Promise((res, rej) => {
      const req = indexedDB.open('sv4_main_store', 1);
      req.onupgradeneeded = e => e.target.result.createObjectStore('kv', { keyPath: 'k' });
      req.onsuccess = e => { this._idbMain = e.target.result; res(); };
      req.onerror   = () => {
        console.warn('IDB init failed — falling back to localStorage');
        this.backend = 'localstorage';
        res();
      };
    });
  },

  async _initOPFS() {
    if (!navigator.storage?.getDirectory) {
      throw new Error('Private File System (OPFS) is not supported in this browser. Try Chrome/Edge.');
    }
    this._opfsRoot  = await navigator.storage.getDirectory();
    this._opfsReady = true;
  },

  // ── READ ────────────────────────────────────────────────────────────────────
  async read() {
    try {
      if (this.backend === 'idb') {
        if (!this._idbMain) await this._initIDB();
        return new Promise(res => {
          const tx  = this._idbMain.transaction('kv', 'readonly');
          const req = tx.objectStore('kv').get(this.DATA_KEY);
          req.onsuccess = e => res(e.target.result ? e.target.result.v : null);
          req.onerror   = () => res(null);
        });
      }

      if (this.backend === 'opfs') {
        if (!this._opfsReady) await this._initOPFS();
        if (this.backend !== 'opfs') return await this.read(); // re-check after possible fallback
        if (!this._opfsRoot) return null;
        try {
          const fh   = await this._opfsRoot.getFileHandle('nullhas_data.json');
          const file = await fh.getFile();
          return await file.text();
        } catch (e) { return null; }
      }

      if (this.backend === 'memory') {
        return this._memoryStore[this.DATA_KEY] || null;
      }

      // default: localStorage
      return localStorage.getItem(this.DATA_KEY);
    } catch (e) {
      return localStorage.getItem(this.DATA_KEY);
    }
  },

  // ── WRITE ───────────────────────────────────────────────────────────────────
  async write(value) {
    try {
      if (this.backend === 'idb') {
        if (!this._idbMain) await this._initIDB();
        return new Promise((res, rej) => {
          const tx = this._idbMain.transaction('kv', 'readwrite');
          tx.objectStore('kv').put({ k: this.DATA_KEY, v: value });
          tx.oncomplete = res;
          tx.onerror    = rej;
        });
      }

      if (this.backend === 'opfs') {
        if (!this._opfsReady) await this._initOPFS();
        if (this.backend !== 'opfs') return await this.write(value);
        if (!this._opfsRoot) throw new Error('OPFS root unavailable');
        const fh       = await this._opfsRoot.getFileHandle('nullhas_data.json', { create: true });
        const writable = await fh.createWritable();
        await writable.write(value);
        await writable.close();
        return;
      }

      if (this.backend === 'memory') {
        this._memoryStore[this.DATA_KEY] = value;
        return;
      }

      // default: localStorage
      localStorage.setItem(this.DATA_KEY, value);
    } catch (e) {
      // Fallback: always try localStorage
      try { localStorage.setItem(this.DATA_KEY, value); } catch (e2) {}
      throw e;
    }
  },

  // ── SWITCH BACKEND ──────────────────────────────────────────────────────────
  switchTo(newBackend, confirmFn) {
    if (newBackend === this.backend) {
      return void (window.toast?.('Already using this storage location'));
    }
    this._pendingBackend = newBackend;
    this._updateUI();
    const labels   = { localstorage:'Browser Storage', idb:'IndexedDB', opfs:'Private File System', memory:'Session Only' };
    const warnings = { memory: '⚠️ Session Only mode — data will be lost on page close!' };
    const opfsHint = newBackend === 'opfs' && !navigator.storage?.getDirectory
      ? ' (OPFS may not be supported in this browser)' : '';
    const msg      = (warnings[newBackend] || '') + opfsHint;
    confirmFn(
      `Switch to ${labels[newBackend]}?`,
      'Your data will be migrated to the new location.' + (msg ? ' ' + msg : ''),
      () => this.migrateAndSwitch(newBackend)
    );
  },

  _executePendingMigration() {
    if (this._pendingBackend && this._pendingBackend !== this.backend) {
      this.migrateAndSwitch(this._pendingBackend);
    } else {
      window.toast?.('No pending storage migration.');
    }
  },

  async migrateAndSwitch(newBackend) {
    const btn    = document.getElementById('sloc-migrate-btn');
    const labels = { localstorage:'Browser Storage', idb:'IndexedDB', opfs:'Private File System', memory:'Session Only' };
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Migrating...'; }

    const oldBackend = this.backend; // save for rollback
    try {
      const currentData = await this.read();
      this.backend = newBackend;
      if (newBackend === 'idb')  await this._initIDB();
      if (newBackend === 'opfs') await this._initOPFS();
      if (currentData) await this.write(currentData);
      try { localStorage.setItem(this.BACKEND_KEY, newBackend); } catch (e) {}
      this._updateUI();
      this._pendingBackend = null;
      window.toast?.('✅ Switched to ' + (labels[newBackend] || newBackend) + ' successfully!');
    } catch (e) {
      this._pendingBackend = null;
      window.toast?.('⚠️ Migration failed: ' + e.message + '. Reverting.');
      this.backend = oldBackend; // use saved old backend, NOT localStorage re-read
      this._updateUI();
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = '⚡ Migrate data & switch storage'; btn.style.display = 'none'; }
    }
  },

  // ── USAGE STATS ─────────────────────────────────────────────────────────────
  async getUsageBytes() {
    try {
      if (this.backend === 'localstorage') {
        return new Blob([localStorage.getItem(this.DATA_KEY) || '']).size;
      }
      if (navigator.storage?.estimate) {
        const est = await navigator.storage.estimate();
        return est.usage || 0;
      }
    } catch (e) {}
    return 0;
  },

  async getQuotaBytes() {
    try {
      if (this.backend === 'localstorage') return 5 * 1024 * 1024;
      if (navigator.storage?.estimate) {
        const est = await navigator.storage.estimate();
        return est.quota || 0;
      }
    } catch (e) {}
    return 5 * 1024 * 1024;
  },

  // ── UPDATE UI ────────────────────────────────────────────────────────────────
  _updateUI() {
    const labels = {
      localstorage: 'Using Browser Storage (localStorage)',
      idb:          'Using IndexedDB (browser database)',
      opfs:         'Using Private File System (OPFS)',
      memory:       'Using Session Memory — data clears on close!'
    };
    ['localstorage', 'idb', 'opfs', 'memory'].forEach(b => {
      document.getElementById('sloc-' + b)?.classList.toggle('active', b === this.backend);
    });
    const st  = document.getElementById('sloc-status-txt');
    if (st) st.textContent = labels[this.backend] || this.backend;

    const dot = document.getElementById('sloc-dot');
    if (dot) dot.style.background = this.backend === 'memory' ? '#facc15' : '#4ade80';

    const limitLbl = document.getElementById('storage-limit-lbl');
    if (limitLbl) {
      const limits = { localstorage:'~5 MB limit', idb:'~50–250 MB', opfs:'Virtually unlimited', memory:'Session only' };
      limitLbl.textContent = limits[this.backend] || '';
    }

    const migrateBtn = document.getElementById('sloc-migrate-btn');
    if (migrateBtn) {
      const hasPending = this._pendingBackend && this._pendingBackend !== this.backend;
      migrateBtn.style.display = hasPending ? 'block' : 'none';
    }
  }
};
