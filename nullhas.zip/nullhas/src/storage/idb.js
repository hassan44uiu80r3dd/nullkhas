// ── INDEXEDDB FILE ATTACHMENT STORE ──────────────────────────────────────────
// Separate IDB store for binary file data (PDF/DOCX attachments)

let _db = null;
const DB_NAME    = 'sv4_files';
const DB_VERSION = 1;
const STORE_NAME = 'files';

export function openDB() {
  return new Promise((res, rej) => {
    if (_db) return res(_db);
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = e => {
      e.target.result.createObjectStore(STORE_NAME, { keyPath: 'id' });
    };
    req.onsuccess = e => { _db = e.target.result; res(_db); };
    req.onerror   = () => rej(req.error);
  });
}

export async function dbSet(id, value) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx  = db.transaction(STORE_NAME, 'readwrite');
    const req = tx.objectStore(STORE_NAME).put({ id, value });
    req.onsuccess = () => res();
    req.onerror   = () => rej(req.error);
  });
}

export async function dbGet(id) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx  = db.transaction(STORE_NAME, 'readonly');
    const req = tx.objectStore(STORE_NAME).get(id);
    req.onsuccess = e => res(e.target.result?.value ?? null);
    req.onerror   = () => rej(req.error);
  });
}

export async function dbDel(id) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx  = db.transaction(STORE_NAME, 'readwrite');
    const req = tx.objectStore(STORE_NAME).delete(id);
    req.onsuccess = () => res();
    req.onerror   = () => rej(req.error);
  });
}
