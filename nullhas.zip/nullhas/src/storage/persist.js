// ── PERSISTENCE ───────────────────────────────────────────────────────────────
import { StorageEngine } from './StorageEngine.js';
import { D } from '../data/store.js';
import { getDefaultSubjects } from '../data/defaults.js';
import { debounce } from '../utils/helpers.js';
import { updateStorageBar } from '../ui/settings.js';

export async function load() {
  try {
    const raw = await StorageEngine.read();
    if (raw) {
      const p = typeof raw === 'string' ? JSON.parse(raw) : raw;
      D.subjects  = p.subjects  || [];
      D.studyLog  = p.studyLog  || [];
      D.settings  = Object.assign(
        { name: '', pinEnabled: false, pin: '', major: '', semester: '' },
        p.settings || {}
      );
    } else {
      D.subjects = getDefaultSubjects();
    }
  } catch (e) {
    console.error('Load failed:', e);
    D.subjects = getDefaultSubjects();
  }
}

const _doPersist = debounce(async () => {
  const serialized = JSON.stringify(D);
  try {
    await StorageEngine.write(serialized);
    updateStorageBar();
  } catch (e) {
    window.toast?.('⚠️ Save failed (' + e.message + '). Try exporting your data!');
  }
}, 300);

export function persist() {
  _doPersist();
}
